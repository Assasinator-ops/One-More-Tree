<?php
/**
 * OneMoreTree Block Patterns Registration
 * Curated block patterns matching the Next.js visual design system
 *
 * @package One_More_Tree
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register OneMoreTree Block Pattern Category and Patterns
 */
function one_more_tree_register_block_patterns() {
    if (!function_exists('register_block_pattern_category')) {
        return;
    }

    // Register Category
    register_block_pattern_category(
        'one-more-tree',
        ['label' => __('One More Tree Patterns', 'one-more-tree')]
    );

    $theme_uri = get_template_directory_uri();

    // 1. Hero Section Pattern
    register_block_pattern(
        'one-more-tree/hero-banner',
        [
            'title'       => __('Hero Banner with Stats', 'one-more-tree'),
            'description' => __('Full-width hero section with mission badge, headline, CTA buttons, and 3 metric cards.', 'one-more-tree'),
            'categories'  => ['one-more-tree', 'header'],
            'content'     => '<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"6rem","bottom":"6rem","left":"2rem","right":"2rem"}}},"backgroundColor":"forest-50","layout":{"type":"constrained","contentSize":"1100px"}} -->
<div class="wp-block-group alignfull has-forest-50-background-color has-background" style="padding-top:6rem;padding-right:2rem;padding-bottom:6rem;padding-left:2rem">
<!-- wp:group {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"0.85rem","fontWeight":"600"}},"backgroundColor":"white","textColor":"forest-700","className":"rounded-full px-4 py-1.5 border border-forest-200 shadow-sm"} -->
<p class="has-text-align-center rounded-full px-4 py-1.5 border border-forest-200 shadow-sm has-forest-700-color has-white-background-color has-text-color has-background" style="font-size:0.85rem">🌳 PLANTING TREES, RESTORING FORESTS</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontSize":"3.5rem","lineHeight":"1.15"}},"fontFamily":"playfair"} -->
<h1 class="wp-block-heading has-text-align-center has-playfair-font-family" style="font-size:3.5rem;lineHeight:1.15">One More <span class="has-forest-700-color" style="font-style:italic">Tree</span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.2rem"}},"textColor":"foreground"} -->
<p class="has-text-align-center has-foreground-color has-text-color" style="font-size:1.2rem">Planting 1 million trees across Spain by 2040. From a conversation among friends to a movement restoring forests.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"2rem","bottom":"3rem"}}}} -->
<div class="wp-block-buttons" style="margin-top:2rem;margin-bottom:3rem">
<!-- wp:button {"backgroundColor":"forest-700","textColor":"white"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-white-color has-forest-700-background-color has-text-color has-background wp-element-button" href="#join">Join the Movement</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#story">Explore Stories</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->

<!-- wp:columns {"style":{"spacing":{"blockGap":"1.5rem"}}} -->
<div class="wp-block-columns">
<!-- wp:column {"style":{"spacing":{"padding":{"top":"1.5rem","bottom":"1.5rem","left":"1.5rem","right":"1.5rem"}}},"backgroundColor":"white","className":"rounded-3xl border border-slate-200 shadow-soft text-center"} -->
<div class="wp-block-column rounded-3xl border border-slate-200 shadow-soft text-center has-white-background-color has-background" style="padding-top:1.5rem;padding-right:1.5rem;padding-bottom:1.5rem;padding-left:1.5rem">
<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"2.5rem"}},"textColor":"forest-600","fontFamily":"playfair"} -->
<h3 class="wp-block-heading has-forest-600-color has-text-color has-playfair-font-family" style="font-size:2.5rem">1,000,000</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.85rem","fontWeight":"600"}},"textColor":"foreground"} -->
<p class="has-foreground-color has-text-color" style="font-size:0.85rem">Trees Tracked</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"1.5rem","bottom":"1.5rem","left":"1.5rem","right":"1.5rem"}}},"backgroundColor":"white","className":"rounded-3xl border border-slate-200 shadow-soft text-center"} -->
<div class="wp-block-column rounded-3xl border border-slate-200 shadow-soft text-center has-white-background-color has-background" style="padding-top:1.5rem;padding-right:1.5rem;padding-bottom:1.5rem;padding-left:1.5rem">
<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"2.5rem"}},"textColor":"forest-600","fontFamily":"playfair"} -->
<h3 class="wp-block-heading has-forest-600-color has-text-color has-playfair-font-family" style="font-size:2.5rem">50+</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.85rem","fontWeight":"600"}},"textColor":"foreground"} -->
<p class="has-foreground-color has-text-color" style="font-size:0.85rem">Active Projects</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"1.5rem","bottom":"1.5rem","left":"1.5rem","right":"1.5rem"}}},"backgroundColor":"white","className":"rounded-3xl border border-slate-200 shadow-soft text-center"} -->
<div class="wp-block-column rounded-3xl border border-slate-200 shadow-soft text-center has-white-background-color has-background" style="padding-top:1.5rem;padding-right:1.5rem;padding-bottom:1.5rem;padding-left:1.5rem">
<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"2.5rem"}},"textColor":"forest-600","fontFamily":"playfair"} -->
<h3 class="wp-block-heading has-forest-600-color has-text-color has-playfair-font-family" style="font-size:2.5rem">10,000+</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.85rem","fontWeight":"600"}},"textColor":"foreground"} -->
<p class="has-foreground-color has-text-color" style="font-size:0.85rem">Volunteers Engaged</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->',
        ]
    );

    // 2. 3-Chapter Story Timeline Pattern
    register_block_pattern(
        'one-more-tree/story-chapters',
        [
            'title'       => __('3-Chapter Restoration Story', 'one-more-tree'),
            'description' => __('Three-stage progressive story milestone cards (The Seed, Growth, Mature Canopy).', 'one-more-tree'),
            'categories'  => ['one-more-tree', 'text'],
            'content'     => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem"}}},"layout":{"type":"constrained","contentSize":"1100px"}} -->
<div class="wp-block-group" style="padding-top:4rem;padding-bottom:4rem">
<!-- wp:heading {"textAlign":"center","level":2,"fontFamily":"playfair"} -->
<h2 class="wp-block-heading has-text-align-center has-playfair-font-family">How a Forest Reclaims the Land</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.1rem"}},"textColor":"foreground"} -->
<p class="has-text-align-center has-foreground-color has-text-color" style="font-size:1.1rem">From tiny seeds to multi-canopy ecosystems, here is the lifecycle of our planting program.</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"style":{"spacing":{"blockGap":"2rem","margin":{"top":"3rem"}}}} -->
<div class="wp-block-columns" style="margin-top:3rem">
<!-- wp:column {"style":{"spacing":{"padding":{"top":"2rem","bottom":"2rem","left":"2rem","right":"2rem"}}},"backgroundColor":"white","className":"rounded-3xl border border-slate-200 shadow-soft"} -->
<div class="wp-block-column rounded-3xl border border-slate-200 shadow-soft has-white-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.75rem","fontWeight":"700"}},"textColor":"forest-700"} -->
<p class="has-forest-700-color has-text-color" style="font-size:0.75rem">CHAPTER 01 • DAY 1</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"1.5rem"}},"fontFamily":"playfair"} -->
<h3 class="wp-block-heading has-playfair-font-family" style="font-size:1.5rem">It Starts with a Seed</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.95rem"}}} -->
<p style="font-size:0.95rem">Carefully selected native acorns and seeds are nestled into prepared earth, paired with organic moisture retainers.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"2rem","bottom":"2rem","left":"2rem","right":"2rem"}}},"backgroundColor":"white","className":"rounded-3xl border border-slate-200 shadow-soft"} -->
<div class="wp-block-column rounded-3xl border border-slate-200 shadow-soft has-white-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.75rem","fontWeight":"700"}},"textColor":"forest-700"} -->
<p class="has-forest-700-color has-text-color" style="font-size:0.75rem">CHAPTER 02 • YEAR 2</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"1.5rem"}},"fontFamily":"playfair"} -->
<h3 class="wp-block-heading has-playfair-font-family" style="font-size:1.5rem">Growing Through Adversity</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.95rem"}}} -->
<p style="font-size:0.95rem">Young saplings brave harsh Iberian summers, protected by protective mesh guards and regular volunteer watering.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"2rem","bottom":"2rem","left":"2rem","right":"2rem"}}},"backgroundColor":"white","className":"rounded-3xl border border-slate-200 shadow-soft"} -->
<div class="wp-block-column rounded-3xl border border-slate-200 shadow-soft has-white-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.75rem","fontWeight":"700"}},"textColor":"forest-700"} -->
<p class="has-forest-700-color has-text-color" style="font-size:0.75rem">CHAPTER 03 • YEAR 10+</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"1.5rem"}},"fontFamily":"playfair"} -->
<h3 class="wp-block-heading has-playfair-font-family" style="font-size:1.5rem">Thriving Canopy</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.95rem"}}} -->
<p style="font-size:0.95rem">A mature woodland stabilizes topsoil, shelters diverse wildlife, and captures thousands of tons of atmospheric carbon.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->',
        ]
    );

    // 3. Project Showcase Feature Card Pattern
    register_block_pattern(
        'one-more-tree/project-showcase',
        [
            'title'       => __('Project Feature Showcase', 'one-more-tree'),
            'description' => __('2-column project spotlight with image, tree statistics, and action link.', 'one-more-tree'),
            'categories'  => ['one-more-tree', 'featured'],
            'content'     => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem"}}},"layout":{"type":"constrained","contentSize":"1100px"}} -->
<div class="wp-block-group" style="padding-top:3rem;padding-bottom:3rem">
<!-- wp:columns {"style":{"spacing":{"blockGap":"2.5rem"}},"className":"rounded-3xl bg-white border border-earth-200 p-8 shadow-elevated items-center"} -->
<div class="wp-block-columns rounded-3xl bg-white border border-earth-200 p-8 shadow-elevated items-center">
<!-- wp:column {"width":"45%"} -->
<div class="wp-block-column" style="flex-basis:45%">
<!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"rounded-2xl overflow-hidden aspect-[4/3] object-cover"} -->
<figure class="wp-block-image size-large rounded-2xl overflow-hidden aspect-[4/3] object-cover"><img src="' . esc_url($theme_uri) . '/assets/images/hero-forest.jpg" alt="Restoration site"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:column -->

<!-- wp:column {"width":"55%"} -->
<div class="wp-block-column" style="flex-basis:55%">
<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.85rem","fontWeight":"600"}},"textColor":"forest-600"} -->
<p class="has-forest-600-color has-text-color" style="font-size:0.85rem">GRANADA, ANDALUSIA • ACTIVE SITE</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"style":{"typography":{"fontSize":"2rem"}},"fontFamily":"playfair"} -->
<h2 class="wp-block-heading has-playfair-font-family" style="font-size:2rem">Sierra Nevada Mountain Forest Recovery</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Re-establishing native pine, oak, and juniper across fire-damaged mountain slopes to protect local watersheds and prevent soil erosion.</p>
<!-- /wp:paragraph -->
<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.9rem","fontWeight":"700"}},"textColor":"forest-700"} -->
<p class="has-forest-700-color has-text-color" style="font-size:0.9rem">🌲 42,500 Trees Planted</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.9rem","fontWeight":"700"}},"textColor":"forest-700"} -->
<p class="has-forest-700-color has-text-color" style="font-size:0.9rem">🤝 850 Volunteers</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"1.5rem"}}}} -->
<div class="wp-block-buttons" style="margin-top:1.5rem">
<!-- wp:button {"backgroundColor":"forest-700","textColor":"white"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-white-color has-forest-700-background-color has-text-color has-background wp-element-button" href="/projects/">View Project Details</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->',
        ]
    );

    // 4. Call to Action / Donation Prompt
    register_block_pattern(
        'one-more-tree/cta-box',
        [
            'title'       => __('Call to Action / Donation Prompt', 'one-more-tree'),
            'description' => __('Full-width high-contrast card urging readers to plant a tree or get involved.', 'one-more-tree'),
            'categories'  => ['one-more-tree', 'call-to-action'],
            'content'     => '<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"backgroundColor":"forest-950","textColor":"white","layout":{"type":"constrained","contentSize":"900px"}} -->
<div class="wp-block-group alignfull has-white-color has-forest-950-background-color has-text-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
<!-- wp:heading {"textAlign":"center","level":2,"style":{"typography":{"fontSize":"2.5rem"}},"textColor":"white","fontFamily":"playfair"} -->
<h2 class="wp-block-heading has-text-align-center has-white-color has-text-color has-playfair-font-family" style="font-size:2.5rem">Every Great Forest Began with One Seed</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.1rem"}},"textColor":"forest-200"} -->
<p class="has-text-align-center has-forest-200-color has-text-color" style="font-size:1.1rem">Join thousands of individuals and companies planting native trees across Spain. Track your tree\'s growth with live GPS coordinates.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"2rem"}}}} -->
<div class="wp-block-buttons" style="margin-top:2rem">
<!-- wp:button {"backgroundColor":"emerald-400","textColor":"forest-950"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-forest-950-color has-emerald-400-background-color has-text-color has-background wp-element-button" href="/donate/">Plant a Tree Today ($25)</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->',
        ]
    );

    // 5. Rich Editorial Article Layout Pattern
    register_block_pattern(
        'one-more-tree/rich-article',
        [
            'title'       => __('Rich Editorial Article Layout', 'one-more-tree'),
            'description' => __('Formatted article with lead paragraph, drop cap, callout quote, and key takeaways container.', 'one-more-tree'),
            'categories'  => ['one-more-tree', 'text'],
            'content'     => '<!-- wp:paragraph {"dropCap":true,"style":{"typography":{"fontSize":"1.15rem"}}} -->
<p class="has-drop-cap" style="font-size:1.15rem">Forest restoration in Mediterranean climates requires a deep understanding of soil microbiomes, native canopy succession, and strategic water retention techniques. Across southern Spain, desertification challenges are being reversed through community-led ecological stewardship.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontFamily":"playfair"} -->
<h2 class="wp-block-heading has-playfair-font-family">Understanding the Microclimate Resilience</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Unlike single-species commercial plantations, biodiverse native groves interplant Holm Oak, Aleppo Pine, and Wild Olive alongside drought-tolerant shrubs like rosemary and thyme. This multilayered structure prevents soil moisture evaporation even during peak summer heatwaves.</p>
<!-- /wp:paragraph -->

<!-- wp:pullquote -->
<figure class="wp-block-pullquote"><blockquote><p>"Restoration isn\'t just putting seedlings in the ground; it is about rebuilding the living sponge of the earth that sustains future generations."</p><cite>Elena Morales, Head of Ecology</cite></blockquote></figure>
<!-- /wp:pullquote -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"2rem","bottom":"2rem","left":"2rem","right":"2rem"}}},"backgroundColor":"forest-50","className":"rounded-2xl border border-forest-200"} -->
<div class="wp-block-group rounded-2xl border border-forest-200 has-forest-50-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"1.25rem"}},"textColor":"forest-800","fontFamily":"playfair"} -->
<h3 class="wp-block-heading has-forest-800-color has-text-color has-playfair-font-family" style="font-size:1.25rem">Key Takeaways from the Field</h3>
<!-- /wp:heading -->
<!-- wp:list -->
<ul>
<li><strong>Native Diversity:</strong> Planting at least 4 complementary species reduces pest vulnerability by 60%.</li>
<li><strong>Organic Mycorrhizae:</strong> Pre-inoculating root systems improves first-year survival rates past 85%.</li>
<li><strong>Community Care:</strong> Quarterly monitoring by local volunteers ensures long-term forest health.</li>
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->',
        ]
    );
}
add_action('init', 'one_more_tree_register_block_patterns');
