/**
 * OneMoreTree Administrator Console Application
 * Full JavaScript implementation matching all Next.js React admin modules with unified WordPress REST backend
 */

(function() {
    'use strict';

    const config = window.OMT_ADMIN_CONFIG || {};

    // ---------------------------------------------------------
    // 1. Handle Login View (if not logged in)
    // ---------------------------------------------------------
    if (!config.isLoggedIn) {
        const loginForm = document.getElementById('admin-login-form');
        const usernameInput = document.getElementById('login-username');
        const passwordInput = document.getElementById('login-password');
        const togglePasswordBtn = document.getElementById('toggle-password-btn');
        const eyeIcon = document.getElementById('eye-icon');
        const errorBox = document.getElementById('login-error-box');
        const errorMsg = document.getElementById('login-error-msg');
        const submitBtn = document.getElementById('login-submit-btn');
        const btnText = document.getElementById('login-btn-text');

        if (togglePasswordBtn && passwordInput) {
            let visible = false;
            togglePasswordBtn.addEventListener('click', function() {
                visible = !visible;
                passwordInput.type = visible ? 'text' : 'password';
                if (eyeIcon) {
                    if (visible) {
                        eyeIcon.innerHTML = `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l18 18"></path>`;
                    } else {
                        eyeIcon.innerHTML = `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>`;
                    }
                }
            });
        }

        if (loginForm) {
            loginForm.addEventListener('submit', async function(e) {
                e.preventDefault();
                if (errorBox) errorBox.classList.add('hidden');
                if (submitBtn) submitBtn.disabled = true;
                if (btnText) {
                    btnText.innerHTML = `
                        <div class="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        <span>Authenticating...</span>
                    `;
                }

                try {
                    const res = await fetch(config.restUrl + 'auth/login', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': config.restNonce
                        },
                        body: JSON.stringify({
                            username: usernameInput.value.trim(),
                            password: passwordInput.value
                        })
                    });

                    const data = await res.json();
                    if (!res.ok || !data.ok) {
                        if (errorMsg) errorMsg.textContent = data.message || 'Invalid administrator credentials.';
                        if (errorBox) {
                            errorBox.classList.remove('hidden');
                            errorBox.classList.add('flex');
                        }
                        if (submitBtn) submitBtn.disabled = false;
                        if (btnText) {
                            btnText.innerHTML = `
                                <span>Access Admin Console</span>
                                <svg class="w-4 h-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                                </svg>
                            `;
                        }
                        return;
                    }

                    // Success!
                    if (btnText) {
                        btnText.innerHTML = `
                            <svg class="w-4 h-4 text-emerald-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                            <span>Access Granted</span>
                        `;
                    }
                    window.location.reload();
                } catch (err) {
                    if (errorMsg) errorMsg.textContent = 'Unable to sign in. Please try again.';
                    if (errorBox) {
                        errorBox.classList.remove('hidden');
                        errorBox.classList.add('flex');
                    }
                    if (submitBtn) submitBtn.disabled = false;
                    if (btnText) {
                        btnText.innerHTML = `
                            <span>Access Admin Console</span>
                            <svg class="w-4 h-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                            </svg>
                        `;
                    }
                }
            });
        }
        return;
    }

    // ---------------------------------------------------------
    // 2. Handle Admin Shell (when logged in)
    // ---------------------------------------------------------
    const logoutBtn = document.getElementById('admin-logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async function() {
            try {
                await fetch(config.restUrl + 'auth/logout', {
                    method: 'POST',
                    headers: { 'X-WP-Nonce': config.restNonce }
                });
            } finally {
                window.location.reload();
            }
        });
    }

    // Navigation Groups Definition (exact match to Next.js AdminShell.tsx)
    const NAVIGATION_GROUPS = [
        {
            name: 'Homepage',
            icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>`,
            pages: [
                { key: 'home-counters', label: 'Home Counters', apiKey: 'home_counters' },
                { key: 'impact-kpis', label: 'Impact KPIs', apiKey: 'impact_kpis' }
            ]
        },
        {
            name: 'Projects',
            icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"></path></svg>`,
            pages: [
                { key: 'projects', label: 'Projects', apiKey: 'projects' },
                { key: 'stories', label: 'Stories', apiKey: 'stories' },
                { key: 'live-map', label: 'Live Map', apiKey: 'live_map' }
            ]
        },
        {
            name: 'Communication',
            icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path></svg>`,
            pages: [
                { key: 'blog', label: 'Blog', apiKey: 'blog' },
                { key: 'newsletter', label: 'Newsletter', apiKey: 'newsletter_subscribers' },
                { key: 'social-media', label: 'Social Media', apiKey: 'social' },
                { key: 'contact', label: 'Contact Inquiries', apiKey: 'contact_submissions' }
            ]
        },
        {
            name: 'Organization',
            icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>`,
            pages: [
                { key: 'team', label: 'Team', apiKey: 'team' },
                { key: 'admin-users', label: 'Admin Users', apiKey: 'admin_users' }
            ]
        },
        {
            name: 'Settings',
            icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path></svg>`,
            pages: [
                { key: 'faq', label: 'FAQ', apiKey: 'faq' },
                { key: 'disclaimer', label: 'Disclaimer', apiKey: 'disclaimer' },
                { key: 'module-status', label: 'Module Visibility', apiKey: 'modules' },
                { key: 'donations', label: 'Donations', apiKey: 'donation_tiers' },
                { key: 'reporting', label: 'Reporting', apiKey: 'reporting' }
            ]
        }
    ];

    let activePageKey = 'home-counters';
    let openGroupDropdown = null;

    // Cache for module data
    const dataCache = {};

    // ---------------------------------------------------------
    // API Helpers
    // ---------------------------------------------------------
    async function fetchAdminData(apiKey, forceReload = false) {
        if (!forceReload && dataCache[apiKey] !== undefined) return dataCache[apiKey];
        try {
            const res = await fetch(`${config.restUrl}admin/data?key=${apiKey}`, {
                headers: { 'X-WP-Nonce': config.restNonce }
            });
            const data = await res.json();
            if (data.ok && data.value !== undefined) {
                dataCache[apiKey] = data.value;
                return data.value;
            }
        } catch (e) {
            console.error('Error fetching admin data:', e);
        }
        return null;
    }

    async function saveAdminData(apiKey, value) {
        dataCache[apiKey] = value;
        try {
            const res = await fetch(`${config.restUrl}admin/data`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': config.restNonce
                },
                body: JSON.stringify({ key: apiKey, value: value })
            });
            return await res.json();
        } catch (e) {
            return { ok: false, error: e.message };
        }
    }

    // Helper notification toast
    function showToast(elementId, message, isSuccess = true) {
        const el = document.getElementById(elementId);
        if (!el) return;
        el.className = `text-xs font-semibold px-3 py-1.5 rounded-lg transition-all ${
            isSuccess ? 'bg-forest-50 text-forest-700 border border-forest-200' : 'bg-red-50 text-red-700 border border-red-200'
        }`;
        el.textContent = message;
        setTimeout(() => {
            if (el) el.textContent = '';
        }, 4000);
    }

    // ---------------------------------------------------------
    // Render Navigation Toolbar
    // ---------------------------------------------------------
    const navContainer = document.getElementById('admin-nav-groups-container');
    function renderNav() {
        if (!navContainer) return;
        navContainer.innerHTML = '';

        NAVIGATION_GROUPS.forEach(group => {
            const hasActive = group.pages.some(p => p.key === activePageKey);
            const isOpen = openGroupDropdown === group.name;

            const groupWrapper = document.createElement('div');
            groupWrapper.className = 'relative';

            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = `inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs sm:text-sm font-medium transition-all ${
                isOpen || hasActive
                    ? 'bg-forest-600 text-white shadow-medium'
                    : 'bg-white/80 border border-earth-200 text-foreground/70 hover:text-foreground hover:bg-white'
            }`;
            btn.innerHTML = `
                ${group.icon}
                <span>${group.name}</span>
                <svg class="w-3.5 h-3.5 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
            `;

            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                openGroupDropdown = (openGroupDropdown === group.name) ? null : group.name;
                renderNav();
            });

            groupWrapper.appendChild(btn);

            if (isOpen) {
                const dropdown = document.createElement('div');
                dropdown.className = 'absolute top-full left-0 mt-2 w-52 bg-white border border-earth-200 rounded-2xl shadow-elevated z-50 overflow-hidden py-1.5 animate-in fade-in slide-in-from-top-1';

                group.pages.forEach(p => {
                    const itemBtn = document.createElement('button');
                    itemBtn.type = 'button';
                    itemBtn.className = `w-full text-left px-4 py-2.5 text-xs sm:text-sm transition-colors ${
                        activePageKey === p.key
                            ? 'bg-forest-50 text-forest-700 font-semibold'
                            : 'text-foreground/70 hover:bg-earth-50 hover:text-foreground'
                    }`;
                    itemBtn.textContent = p.label;
                    itemBtn.addEventListener('click', () => {
                        activePageKey = p.key;
                        openGroupDropdown = null;
                        renderNav();
                        loadAndRenderActiveModule();
                    });
                    dropdown.appendChild(itemBtn);
                });

                groupWrapper.appendChild(dropdown);
            }

            navContainer.appendChild(groupWrapper);
        });
    }

    document.addEventListener('click', () => {
        if (openGroupDropdown) {
            openGroupDropdown = null;
            renderNav();
        }
    });

    // ---------------------------------------------------------
    // Module Renderers Router
    // ---------------------------------------------------------
    const moduleContent = document.getElementById('admin-module-content');

    async function loadAndRenderActiveModule() {
        if (!moduleContent) return;
        moduleContent.innerHTML = `
            <div class="py-16 text-center text-foreground/50">
                <div class="inline-block w-8 h-8 border-4 border-forest-600 border-t-transparent rounded-full animate-spin mb-3"></div>
                <p class="text-sm">Loading module data...</p>
            </div>
        `;

        switch (activePageKey) {
            case 'home-counters':
                renderHomeCounters();
                break;
            case 'impact-kpis':
                renderImpactKpis();
                break;
            case 'projects':
                renderProjects();
                break;
            case 'stories':
                renderStories();
                break;
            case 'live-map':
                renderLiveMap();
                break;
            case 'faq':
                renderFaq();
                break;
            case 'donations':
                renderDonations();
                break;
            case 'contact':
                renderContact();
                break;
            case 'newsletter':
                renderNewsletter();
                break;
            case 'social-media':
                renderSocialMedia();
                break;
            case 'team':
                renderTeam();
                break;
            case 'disclaimer':
                renderDisclaimer();
                break;
            case 'module-status':
                renderModuleStatus();
                break;
            case 'blog':
                renderBlog();
                break;
            case 'admin-users':
                renderAdminUsers();
                break;
            case 'reporting':
            default:
                renderReporting();
                break;
        }
    }

    // =========================================================
    // 1. HOME COUNTERS MODULE
    // =========================================================
    async function renderHomeCounters() {
        const data = await fetchAdminData('home_counters') || {
            treesTracked: 1000000,
            projectsActive: 50,
            volunteersEngaged: 10000,
            regionsCovered: 4
        };

        moduleContent.innerHTML = `
            <div class="space-y-6 animate-in fade-in">
                <div>
                    <h2 class="font-serif text-2xl font-bold text-foreground">Home Counters</h2>
                    <p class="text-xs sm:text-sm text-foreground/60">Live metrics shown in the homepage hero and counter badges.</p>
                </div>
                <div class="grid gap-4 sm:grid-cols-2">
                    <div class="p-4 bg-white rounded-2xl border border-earth-200 shadow-soft">
                        <label class="block text-xs font-semibold text-foreground/70 mb-1">Trees Tracked</label>
                        <input id="hc-trees" type="number" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm focus:border-forest-500 outline-none" value="${data.treesTracked}">
                        <p class="text-[11px] text-foreground/40 mt-1">Total trees planted across all active restoration sites.</p>
                    </div>
                    <div class="p-4 bg-white rounded-2xl border border-earth-200 shadow-soft">
                        <label class="block text-xs font-semibold text-foreground/70 mb-1">Projects Active</label>
                        <input id="hc-projects" type="number" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm focus:border-forest-500 outline-none" value="${data.projectsActive}">
                        <p class="text-[11px] text-foreground/40 mt-1">Active forest and urban greening initiatives in Spain.</p>
                    </div>
                    <div class="p-4 bg-white rounded-2xl border border-earth-200 shadow-soft">
                        <label class="block text-xs font-semibold text-foreground/70 mb-1">Volunteers Engaged</label>
                        <input id="hc-volunteers" type="number" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm focus:border-forest-500 outline-none" value="${data.volunteersEngaged}">
                        <p class="text-[11px] text-foreground/40 mt-1">Community participants and local guardians.</p>
                    </div>
                    <div class="p-4 bg-white rounded-2xl border border-earth-200 shadow-soft">
                        <label class="block text-xs font-semibold text-foreground/70 mb-1">Regions Covered</label>
                        <input id="hc-regions" type="number" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm focus:border-forest-500 outline-none" value="${data.regionsCovered}">
                        <p class="text-[11px] text-foreground/40 mt-1">Autonomous communities with active plantings.</p>
                    </div>
                </div>
                <div class="flex items-center gap-4 pt-4 border-t border-earth-200">
                    <button id="hc-save-btn" class="px-6 py-2.5 bg-forest-600 hover:bg-forest-700 text-white font-semibold text-sm rounded-xl transition shadow-medium">Save Changes</button>
                    <span id="hc-status"></span>
                </div>
            </div>
        `;

        document.getElementById('hc-save-btn').addEventListener('click', async () => {
            const next = {
                treesTracked: parseInt(document.getElementById('hc-trees').value, 10) || 0,
                projectsActive: parseInt(document.getElementById('hc-projects').value, 10) || 0,
                volunteersEngaged: parseInt(document.getElementById('hc-volunteers').value, 10) || 0,
                regionsCovered: parseInt(document.getElementById('hc-regions').value, 10) || 0
            };
            const res = await saveAdminData('home_counters', next);
            showToast('hc-status', res.ok ? `Saved successfully at ${res.savedAt || new Date().toLocaleTimeString()}!` : 'Error saving.', res.ok);
        });
    }

    // =========================================================
    // 2. IMPACT KPIS MODULE
    // =========================================================
    async function renderImpactKpis() {
        const data = await fetchAdminData('impact_kpis') || {
            goalTarget: 1000000,
            goalCurrent: 847000,
            kpis: [
                { label: 'Regions Covered', value: '4', sub: 'Granada, Madrid, Valencia, Galicia' },
                { label: 'Projects Active', value: '12', sub: 'Active forest & urban sites' },
                { label: 'Tons CO2 Absorbed', value: '4,850', sub: 'Estimated lifetime absorption' },
                { label: 'Volunteers Engaged', value: '2,420', sub: 'Community participants' }
            ]
        };

        const pct = Math.min(100, Math.round((data.goalCurrent / (data.goalTarget || 1000000)) * 1000) / 10);

        moduleContent.innerHTML = `
            <div class="space-y-6 animate-in fade-in">
                <div>
                    <h2 class="font-serif text-2xl font-bold text-foreground">Impact KPIs & 2040 Goal</h2>
                    <p class="text-xs sm:text-sm text-foreground/60">Manage the 2040 tree planting progress bar and 4 KPI cards on the Impact page.</p>
                </div>
                <div class="p-5 bg-white rounded-2xl border border-earth-200 space-y-4 shadow-soft">
                    <div class="flex items-center justify-between">
                        <h3 class="font-semibold text-sm text-foreground">Milestone Progress Bar (${pct}%)</h3>
                    </div>
                    <div class="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                        <div class="h-full bg-forest-600 rounded-full transition-all duration-500" style="width: ${pct}%"></div>
                    </div>
                    <div class="grid sm:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-semibold text-foreground/70 mb-1">Goal Target (Trees)</label>
                            <input id="ik-target" type="number" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm focus:border-forest-500 outline-none" value="${data.goalTarget}">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-foreground/70 mb-1">Current Progress (Trees)</label>
                            <input id="ik-current" type="number" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm focus:border-forest-500 outline-none" value="${data.goalCurrent}">
                        </div>
                    </div>
                </div>

                <div class="grid sm:grid-cols-2 gap-4">
                    ${data.kpis.map((k, i) => `
                        <div class="p-4 bg-white rounded-2xl border border-earth-200 space-y-2 shadow-soft">
                            <label class="block text-xs font-semibold text-forest-700">KPI Card #${i + 1}</label>
                            <input id="ik-kpi-lbl-${i}" type="text" class="w-full px-4 py-2 rounded-xl border border-earth-200 text-xs font-semibold" value="${k.label}" placeholder="Label">
                            <input id="ik-kpi-val-${i}" type="text" class="w-full px-4 py-2 rounded-xl border border-earth-200 text-sm font-bold text-foreground" value="${k.value}" placeholder="Value (e.g. 4,850)">
                            <input id="ik-kpi-sub-${i}" type="text" class="w-full px-4 py-2 rounded-xl border border-earth-200 text-xs text-foreground/60" value="${k.sub}" placeholder="Description">
                        </div>
                    `).join('')}
                </div>

                <div class="flex items-center gap-4 pt-4 border-t border-earth-200">
                    <button id="ik-save-btn" class="px-6 py-2.5 bg-forest-600 hover:bg-forest-700 text-white font-semibold text-sm rounded-xl transition shadow-medium">Save Impact KPIs</button>
                    <span id="ik-status"></span>
                </div>
            </div>
        `;

        document.getElementById('ik-save-btn').addEventListener('click', async () => {
            const next = {
                goalTarget: parseInt(document.getElementById('ik-target').value, 10) || 1000000,
                goalCurrent: parseInt(document.getElementById('ik-current').value, 10) || 0,
                kpis: data.kpis.map((k, i) => ({
                    label: document.getElementById(`ik-kpi-lbl-${i}`).value.trim(),
                    value: document.getElementById(`ik-kpi-val-${i}`).value.trim(),
                    sub: document.getElementById(`ik-kpi-sub-${i}`).value.trim()
                }))
            };
            const res = await saveAdminData('impact_kpis', next);
            showToast('ik-status', res.ok ? `Saved successfully at ${res.savedAt || new Date().toLocaleTimeString()}!` : 'Error saving.', res.ok);
        });
    }

    // =========================================================
    // 3. PROJECTS CATALOG & MILESTONES MODULE (Full CRUD)
    // =========================================================
    async function renderProjects() {
        const raw = await fetchAdminData('projects') || { items: [] };
        const projectsList = Array.isArray(raw.items) ? raw.items : (Array.isArray(raw.projects) ? raw.projects : (Array.isArray(raw) ? raw : []));
        
        let selectedIndex = 0;
        if (projectsList.length === 0) {
            projectsList.push({
                id: 'sierra-nevada',
                title: 'Sierra Nevada Restoration',
                region: 'Granada, Andalusia',
                description: 'High-altitude mountain forest recovery program planting native pine and oak.',
                trees: 42500,
                volunteers: 850,
                status: 'Active',
                active: true,
                milestones: [
                    { id: 'm-1', title: 'Land Preparation', description: 'Soil preparation and organic fertilizing', date: '2023-01-15', status: 'Completed' }
                ]
            });
        }

        function drawProjectsUI() {
            const current = projectsList[selectedIndex] || projectsList[0];

            moduleContent.innerHTML = `
                <div class="space-y-6 animate-in fade-in">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="font-serif text-2xl font-bold text-foreground">Projects Catalog & Milestones</h2>
                            <p class="text-xs sm:text-sm text-foreground/60">Manage active restoration initiatives, tree totals, and step-by-step milestones.</p>
                        </div>
                        <button id="proj-add-btn" class="px-4 py-2 bg-forest-600 hover:bg-forest-700 text-white text-xs font-semibold rounded-xl transition shadow-soft flex items-center gap-1.5">
                            <span>+ New Project</span>
                        </button>
                    </div>

                    <div class="grid lg:grid-cols-3 gap-6">
                        <!-- Projects Sidebar List -->
                        <div class="space-y-3">
                            <div class="text-xs font-bold uppercase tracking-wider text-foreground/50 mb-2">Projects (${projectsList.length})</div>
                            ${projectsList.map((p, idx) => `
                                <div class="proj-item-card p-4 rounded-2xl border transition-all cursor-pointer ${
                                    idx === selectedIndex ? 'border-forest-500 bg-forest-50 shadow-soft' : 'border-earth-200 bg-white hover:bg-slate-50'
                                }" data-idx="${idx}">
                                    <div class="flex items-center justify-between mb-1">
                                        <h4 class="font-serif font-bold text-sm text-foreground truncate">${p.title || p.name || 'Untitled Project'}</h4>
                                        <span class="text-[10px] font-semibold px-2 py-0.5 rounded-full ${p.active !== false ? 'bg-forest-100 text-forest-700' : 'bg-slate-100 text-slate-500'}">
                                            ${p.status || (p.active !== false ? 'Active' : 'Archived')}
                                        </span>
                                    </div>
                                    <div class="text-xs text-foreground/60 truncate">${p.region || 'Spain'}</div>
                                    <div class="text-[11px] text-forest-600 font-medium mt-2">${(p.trees || p.treesPlanted || 0).toLocaleString()} trees • ${p.volunteers || 0} volunteers</div>
                                </div>
                            `).join('')}
                        </div>

                        <!-- Selected Project Editor -->
                        <div class="lg:col-span-2 space-y-5 bg-white p-6 rounded-3xl border border-earth-200 shadow-soft">
                            <div class="flex items-center justify-between border-b border-earth-100 pb-4">
                                <h3 class="font-serif text-lg font-bold text-foreground">Edit: ${current.title || current.name || 'Project Details'}</h3>
                                <button id="proj-delete-btn" class="text-xs text-red-500 hover:text-red-700 font-semibold px-3 py-1.5 rounded-lg hover:bg-red-50 transition">Delete Project</button>
                            </div>

                            <div class="grid sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-xs font-semibold text-foreground/70 mb-1">Project Title</label>
                                    <input id="proj-title" type="text" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm font-semibold" value="${current.title || current.name || ''}">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-foreground/70 mb-1">Region / Location</label>
                                    <input id="proj-region" type="text" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm" value="${current.region || ''}">
                                </div>
                            </div>

                            <div>
                                <label class="block text-xs font-semibold text-foreground/70 mb-1">Description</label>
                                <textarea id="proj-desc" rows="3" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm">${current.description || ''}</textarea>
                            </div>

                            <div class="grid sm:grid-cols-3 gap-4">
                                <div>
                                    <label class="block text-xs font-semibold text-foreground/70 mb-1">Trees Planted</label>
                                    <input id="proj-trees" type="number" class="w-full px-4 py-2 rounded-xl border border-earth-200 text-sm" value="${current.trees || current.treesPlanted || 0}">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-foreground/70 mb-1">Volunteers Engaged</label>
                                    <input id="proj-vol" type="number" class="w-full px-4 py-2 rounded-xl border border-earth-200 text-sm" value="${current.volunteers || 0}">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-foreground/70 mb-1">Status Label</label>
                                    <input id="proj-status" type="text" class="w-full px-4 py-2 rounded-xl border border-earth-200 text-sm" value="${current.status || 'Active'}">
                                </div>
                            </div>

                            <!-- Milestones List -->
                            <div class="pt-4 border-t border-earth-100 space-y-3">
                                <div class="flex items-center justify-between">
                                    <label class="text-xs font-bold uppercase tracking-wider text-foreground/70">Project Milestones (${(current.milestones || []).length})</label>
                                    <button id="ms-add-btn" class="text-xs text-forest-700 hover:text-forest-800 font-semibold">+ Add Milestone</button>
                                </div>

                                <div id="milestones-container" class="space-y-2.5">
                                    ${(current.milestones || []).map((m, mIdx) => `
                                        <div class="p-3 bg-slate-50 rounded-xl border border-earth-200 grid sm:grid-cols-4 gap-2 items-center">
                                            <input type="text" class="ms-title sm:col-span-2 px-3 py-1.5 rounded-lg border border-earth-200 text-xs font-semibold bg-white" value="${m.title || ''}" placeholder="Milestone name">
                                            <input type="date" class="ms-date px-3 py-1.5 rounded-lg border border-earth-200 text-xs bg-white" value="${m.date || ''}">
                                            <div class="flex items-center gap-2">
                                                <input type="text" class="ms-status flex-1 px-3 py-1.5 rounded-lg border border-earth-200 text-xs bg-white" value="${m.status || 'Planned'}" placeholder="Status">
                                                <button class="ms-del-btn text-xs text-red-500 hover:text-red-700 px-1" data-midx="${mIdx}">✕</button>
                                            </div>
                                            <textarea class="ms-desc sm:col-span-4 px-3 py-1.5 rounded-lg border border-earth-200 text-xs bg-white text-foreground/70" rows="1" placeholder="Milestone description">${m.description || ''}</textarea>
                                        </div>
                                    `).join('')}
                                </div>
                            </div>

                            <!-- Save / Feedback -->
                            <div class="flex items-center gap-4 pt-4 border-t border-earth-200">
                                <button id="proj-save-btn" class="px-6 py-2.5 bg-forest-600 hover:bg-forest-700 text-white font-semibold text-sm rounded-xl transition shadow-medium">Save All Projects</button>
                                <span id="proj-save-status"></span>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            // Select project listener
            document.querySelectorAll('.proj-item-card').forEach(card => {
                card.addEventListener('click', function() {
                    selectedIndex = parseInt(this.getAttribute('data-idx'), 10);
                    drawProjectsUI();
                });
            });

            // Add new project
            document.getElementById('proj-add-btn').addEventListener('click', () => {
                const newProj = {
                    id: `project-${Date.now()}`,
                    title: 'New Restoration Site',
                    region: 'Spain',
                    description: 'A newly launched forest regeneration initiative.',
                    trees: 5000,
                    volunteers: 50,
                    status: 'Active',
                    active: true,
                    milestones: []
                };
                projectsList.unshift(newProj);
                selectedIndex = 0;
                drawProjectsUI();
            });

            // Delete project
            document.getElementById('proj-delete-btn').addEventListener('click', () => {
                if (confirm('Are you sure you want to delete this project?')) {
                    projectsList.splice(selectedIndex, 1);
                    selectedIndex = Math.max(0, selectedIndex - 1);
                    drawProjectsUI();
                }
            });

            // Add milestone
            document.getElementById('ms-add-btn').addEventListener('click', () => {
                if (!current.milestones) current.milestones = [];
                current.milestones.push({
                    id: `m-${Date.now()}`,
                    title: 'New Milestone',
                    description: 'Description of milestone',
                    date: new Date().toISOString().slice(0, 10),
                    status: 'Planned'
                });
                drawProjectsUI();
            });

            // Delete milestone
            document.querySelectorAll('.ms-del-btn').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const mIdx = parseInt(this.getAttribute('data-midx'), 10);
                    current.milestones.splice(mIdx, 1);
                    drawProjectsUI();
                });
            });

            // Save Projects
            document.getElementById('proj-save-btn').addEventListener('click', async () => {
                // Update currently open project from inputs
                current.title = document.getElementById('proj-title').value.trim();
                current.name = current.title;
                current.region = document.getElementById('proj-region').value.trim();
                current.description = document.getElementById('proj-desc').value.trim();
                current.trees = parseInt(document.getElementById('proj-trees').value, 10) || 0;
                current.treesPlanted = current.trees;
                current.volunteers = parseInt(document.getElementById('proj-vol').value, 10) || 0;
                current.status = document.getElementById('proj-status').value.trim();

                const msCards = document.querySelectorAll('#milestones-container > div');
                current.milestones = [];
                msCards.forEach(card => {
                    current.milestones.push({
                        title: card.querySelector('.ms-title').value.trim(),
                        date: card.querySelector('.ms-date').value,
                        status: card.querySelector('.ms-status').value.trim(),
                        description: card.querySelector('.ms-desc').value.trim()
                    });
                });

                const payload = { items: projectsList, projects: projectsList };
                const res = await saveAdminData('projects', payload);
                showToast('proj-save-status', res.ok ? `Saved successfully at ${res.savedAt || new Date().toLocaleTimeString()}!` : 'Error saving.', res.ok);
            });
        }

        drawProjectsUI();
    }

    // =========================================================
    // 4. LIVE MAP & PHOTOS MODULE (Full Interactive Map Editor)
    // =========================================================
    async function renderLiveMap() {
        const raw = await fetchAdminData('live_map') || {};
        const locations = Array.isArray(raw.locations) ? raw.locations : [];
        let selectedLocIndex = 0;

        if (locations.length === 0) {
            locations.push({
                id: 'sierra-nevada',
                name: 'Sierra Nevada Restoration',
                region: 'Granada, Andalusia',
                description: 'Mountain forest restoration project',
                coords: { x: '35%', y: '75%' },
                treesPlanted: 42500,
                volunteers: 850,
                progressImages: [
                    { title: 'Project Start', description: 'Initial site preparation', image: config.themeUrl + '/assets/images/seedling.jpg', date: 'Jan 2023' }
                ],
                events: []
            });
        }

        function drawMapUI() {
            const loc = locations[selectedLocIndex] || locations[0];

            moduleContent.innerHTML = `
                <div class="space-y-6 animate-in fade-in">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="font-serif text-2xl font-bold text-foreground">Interactive Tree Map & Photo Slideshows</h2>
                            <p class="text-xs sm:text-sm text-foreground/60">Configure pin coordinates, tree counts, and photo milestones on the live Spain map.</p>
                        </div>
                        <button id="map-add-loc-btn" class="px-4 py-2 bg-forest-600 hover:bg-forest-700 text-white text-xs font-semibold rounded-xl transition shadow-soft flex items-center gap-1.5">
                            <span>+ Add Location</span>
                        </button>
                    </div>

                    <div class="grid lg:grid-cols-3 gap-6">
                        <!-- Locations List -->
                        <div class="space-y-3">
                            <div class="text-xs font-bold uppercase tracking-wider text-foreground/50 mb-2">Map Pins (${locations.length})</div>
                            ${locations.map((l, idx) => `
                                <div class="map-loc-card p-4 rounded-2xl border transition-all cursor-pointer ${
                                    idx === selectedLocIndex ? 'border-forest-500 bg-forest-50 shadow-soft' : 'border-earth-200 bg-white hover:bg-slate-50'
                                }" data-locidx="${idx}">
                                    <div class="flex items-center justify-between mb-1">
                                        <h4 class="font-serif font-bold text-sm text-foreground truncate">${l.name}</h4>
                                        <span class="text-[10px] font-mono bg-slate-100 px-2 py-0.5 rounded-md text-foreground/70">${l.coords?.x || '50%'}, ${l.coords?.y || '50%'}</span>
                                    </div>
                                    <div class="text-xs text-foreground/60 truncate">${l.region}</div>
                                    <div class="text-[11px] text-forest-600 font-medium mt-1.5">${(l.treesPlanted || 0).toLocaleString()} trees • ${(l.progressImages || []).length} photos</div>
                                </div>
                            `).join('')}
                        </div>

                        <!-- Location & Map Editor -->
                        <div class="lg:col-span-2 space-y-6 bg-white p-6 rounded-3xl border border-earth-200 shadow-soft">
                            <div class="flex items-center justify-between border-b border-earth-100 pb-4">
                                <h3 class="font-serif text-lg font-bold text-foreground">Pin: ${loc.name}</h3>
                                ${locations.length > 1 ? `<button id="map-del-loc-btn" class="text-xs text-red-500 hover:text-red-700 font-semibold px-3 py-1.5 rounded-lg hover:bg-red-50 transition">Remove Pin</button>` : ''}
                            </div>

                            <div class="grid sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-xs font-semibold text-foreground/70 mb-1">Site / Location Name</label>
                                    <input id="loc-name" type="text" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm font-semibold" value="${loc.name || ''}">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-foreground/70 mb-1">Region</label>
                                    <input id="loc-region" type="text" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm" value="${loc.region || ''}">
                                </div>
                            </div>

                            <div>
                                <label class="block text-xs font-semibold text-foreground/70 mb-1">Description</label>
                                <textarea id="loc-desc" rows="2" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm">${loc.description || ''}</textarea>
                            </div>

                            <div class="grid sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-xs font-semibold text-foreground/70 mb-1">Trees Planted</label>
                                    <input id="loc-trees" type="number" class="w-full px-4 py-2 rounded-xl border border-earth-200 text-sm" value="${loc.treesPlanted || 0}">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-foreground/70 mb-1">Volunteers</label>
                                    <input id="loc-vol" type="number" class="w-full px-4 py-2 rounded-xl border border-earth-200 text-sm" value="${loc.volunteers || 0}">
                                </div>
                            </div>

                            <!-- Interactive Click-to-Pin Visual Map -->
                            <div class="space-y-2">
                                <label class="block text-xs font-bold uppercase tracking-wider text-foreground/70">Map Coordinates (Click on map to position pin)</label>
                                <div id="interactive-spain-map" class="relative w-full aspect-[16/9] bg-forest-950/90 rounded-2xl overflow-hidden border border-forest-800 cursor-crosshair group shadow-inner">
                                    <div class="absolute inset-0 leaf-pattern opacity-20 pointer-events-none"></div>
                                    <div class="absolute inset-0 flex items-center justify-center pointer-events-none">
                                        <span class="text-white/20 font-serif text-3xl font-bold tracking-widest uppercase">Spain & Europe Map</span>
                                    </div>
                                    <!-- Render Pin Marker -->
                                    <div id="map-target-pin" class="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center pointer-events-none transition-all duration-150" style="left: ${loc.coords?.x || '50%'}; top: ${loc.coords?.y || '50%'}">
                                        <div class="w-6 h-6 rounded-full bg-forest-500 border-2 border-white shadow-elevated flex items-center justify-center animate-bounce">
                                            <div class="w-2 h-2 bg-white rounded-full"></div>
                                        </div>
                                        <div class="text-[10px] font-bold text-white bg-black/80 px-2 py-0.5 rounded mt-1 whitespace-nowrap shadow">${loc.name || 'Pin'}</div>
                                    </div>
                                </div>
                                <div class="grid grid-cols-2 gap-4 pt-1">
                                    <div class="flex items-center gap-2">
                                        <span class="text-xs text-foreground/50 font-mono">X Coord:</span>
                                        <input id="loc-coord-x" type="text" class="w-full px-3 py-1.5 rounded-lg border border-earth-200 text-xs font-mono" value="${loc.coords?.x || '50%'}">
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <span class="text-xs text-foreground/50 font-mono">Y Coord:</span>
                                        <input id="loc-coord-y" type="text" class="w-full px-3 py-1.5 rounded-lg border border-earth-200 text-xs font-mono" value="${loc.coords?.y || '50%'}">
                                    </div>
                                </div>
                            </div>

                            <!-- Photo Progress Slideshow CRUD -->
                            <div class="pt-4 border-t border-earth-100 space-y-3">
                                <div class="flex items-center justify-between">
                                    <label class="text-xs font-bold uppercase tracking-wider text-foreground/70">Progress Photos (${(loc.progressImages || []).length})</label>
                                    <button id="pimg-add-btn" class="text-xs text-forest-700 hover:text-forest-800 font-semibold">+ Add Photo</button>
                                </div>

                                <div id="pimg-container" class="space-y-3">
                                    ${(loc.progressImages || []).map((img, imgIdx) => `
                                        <div class="p-3 bg-slate-50 rounded-xl border border-earth-200 grid sm:grid-cols-4 gap-3 items-center">
                                            <div class="sm:col-span-1 aspect-video rounded-lg overflow-hidden border border-earth-200 bg-earth-100 relative">
                                                <img src="${img.image || config.themeUrl + '/assets/images/seedling.jpg'}" class="w-full h-full object-cover" onerror="this.src='${config.themeUrl}/assets/images/seedling.jpg'">
                                            </div>
                                            <div class="sm:col-span-3 space-y-1.5">
                                                <div class="flex items-center gap-2">
                                                    <input type="text" class="pimg-title flex-1 px-3 py-1.5 rounded-lg border border-earth-200 text-xs font-semibold bg-white" value="${img.title || ''}" placeholder="Photo title / phase">
                                                    <input type="text" class="pimg-date w-28 px-3 py-1.5 rounded-lg border border-earth-200 text-xs bg-white" value="${img.date || ''}" placeholder="Date / Month">
                                                    <button class="pimg-del-btn text-xs text-red-500 hover:text-red-700 px-1" data-imgidx="${imgIdx}">✕</button>
                                                </div>
                                                <input type="text" class="pimg-url w-full px-3 py-1.5 rounded-lg border border-earth-200 text-xs bg-white" value="${img.image || ''}" placeholder="Image URL">
                                                <textarea class="pimg-desc w-full px-3 py-1.5 rounded-lg border border-earth-200 text-xs bg-white" rows="1" placeholder="Caption / description">${img.description || ''}</textarea>
                                            </div>
                                        </div>
                                    `).join('')}
                                </div>
                            </div>

                            <!-- Save Button -->
                            <div class="flex items-center gap-4 pt-4 border-t border-earth-200">
                                <button id="map-save-btn" class="px-6 py-2.5 bg-forest-600 hover:bg-forest-700 text-white font-semibold text-sm rounded-xl transition shadow-medium">Save Live Map</button>
                                <span id="map-save-status"></span>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            // Select Location
            document.querySelectorAll('.map-loc-card').forEach(card => {
                card.addEventListener('click', function() {
                    selectedLocIndex = parseInt(this.getAttribute('data-locidx'), 10);
                    drawMapUI();
                });
            });

            // Add Location
            document.getElementById('map-add-loc-btn').addEventListener('click', () => {
                locations.push({
                    id: `location-${Date.now()}`,
                    name: 'New Planting Site',
                    region: 'Spain',
                    description: 'Description of the site',
                    coords: { x: '50%', y: '50%' },
                    treesPlanted: 1000,
                    volunteers: 20,
                    progressImages: [],
                    events: []
                });
                selectedLocIndex = locations.length - 1;
                drawMapUI();
            });

            // Delete Location
            const delBtn = document.getElementById('map-del-loc-btn');
            if (delBtn) {
                delBtn.addEventListener('click', () => {
                    if (confirm('Delete this map location?')) {
                        locations.splice(selectedLocIndex, 1);
                        selectedLocIndex = Math.max(0, selectedLocIndex - 1);
                        drawMapUI();
                    }
                });
            }

            // Click-to-Pin on Map
            const mapEl = document.getElementById('interactive-spain-map');
            if (mapEl) {
                mapEl.addEventListener('click', function(e) {
                    const rect = mapEl.getBoundingClientRect();
                    const clickX = Math.round(((e.clientX - rect.left) / rect.width) * 100);
                    const clickY = Math.round(((e.clientY - rect.top) / rect.height) * 100);

                    const xStr = clickX + '%';
                    const yStr = clickY + '%';

                    loc.coords = { x: xStr, y: yStr };
                    document.getElementById('loc-coord-x').value = xStr;
                    document.getElementById('loc-coord-y').value = yStr;

                    const pin = document.getElementById('map-target-pin');
                    if (pin) {
                        pin.style.left = xStr;
                        pin.style.top = yStr;
                    }
                });
            }

            // Add Photo
            document.getElementById('pimg-add-btn').addEventListener('click', () => {
                if (!loc.progressImages) loc.progressImages = [];
                loc.progressImages.push({
                    title: 'New Progress Photo',
                    description: 'Photo description',
                    image: config.themeUrl + '/assets/images/sapling.jpg',
                    date: '2024'
                });
                drawMapUI();
            });

            // Delete Photo
            document.querySelectorAll('.pimg-del-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const imgIdx = parseInt(this.getAttribute('data-imgidx'), 10);
                    loc.progressImages.splice(imgIdx, 1);
                    drawMapUI();
                });
            });

            // Save Live Map
            document.getElementById('map-save-btn').addEventListener('click', async () => {
                loc.name = document.getElementById('loc-name').value.trim();
                loc.region = document.getElementById('loc-region').value.trim();
                loc.description = document.getElementById('loc-desc').value.trim();
                loc.treesPlanted = parseInt(document.getElementById('loc-trees').value, 10) || 0;
                loc.volunteers = parseInt(document.getElementById('loc-vol').value, 10) || 0;
                loc.coords = {
                    x: document.getElementById('loc-coord-x').value.trim(),
                    y: document.getElementById('loc-coord-y').value.trim()
                };

                const imgCards = document.querySelectorAll('#pimg-container > div');
                loc.progressImages = [];
                imgCards.forEach(card => {
                    loc.progressImages.push({
                        title: card.querySelector('.pimg-title').value.trim(),
                        date: card.querySelector('.pimg-date').value.trim(),
                        image: card.querySelector('.pimg-url').value.trim(),
                        description: card.querySelector('.pimg-desc').value.trim()
                    });
                });

                const payload = { locations: locations };
                const res = await saveAdminData('live_map', payload);
                showToast('map-save-status', res.ok ? `Saved at ${res.savedAt || new Date().toLocaleTimeString()}!` : 'Error saving.', res.ok);
            });
        }

        drawMapUI();
    }

    // =========================================================
    // 5. TEAM MODULE (Full CRUD)
    // =========================================================
    async function renderTeam() {
        const raw = await fetchAdminData('team') || {};
        const draft = {
            sectionTitle: raw.sectionTitle || 'Our Team',
            headline: raw.headline || 'People who make planting real',
            description: raw.description || 'From field work to reporting, our team and partners keep restoration accountable and alive.',
            members: Array.isArray(raw.members) ? raw.members : [
                { name: 'Elena Morales', role: 'Head of Ecology & Native Forestry', experience: '15+ yrs restoration', highlight: '15+ yrs restoration', image: '' },
                { name: 'David Gomez', role: 'Operations & Community Stewardship', experience: 'Camino route lead', highlight: 'Camino route lead', image: '' }
            ],
            stats: Array.isArray(raw.stats) ? raw.stats : [
                { value: '100%', label: 'Native species focus' },
                { value: '15+', label: 'Community partners' },
                { value: '4', label: 'Active Spanish regions' }
            ]
        };

        function drawTeamUI() {
            moduleContent.innerHTML = `
                <div class="space-y-6 animate-in fade-in">
                    <div>
                        <h2 class="font-serif text-2xl font-bold text-foreground">Team Profiles & Supporting Stats</h2>
                        <p class="text-xs sm:text-sm text-foreground/60">Manage team members, leadership roles, and impact metrics shown on the About page.</p>
                    </div>

                    <!-- Header Details -->
                    <div class="p-5 bg-white rounded-3xl border border-earth-200 space-y-4 shadow-soft">
                        <div class="grid sm:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-xs font-semibold text-foreground/70 mb-1">Section Badge Title</label>
                                <input id="team-title" type="text" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm font-semibold" value="${draft.sectionTitle}">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-foreground/70 mb-1">Headline</label>
                                <input id="team-headline" type="text" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm font-semibold" value="${draft.headline}">
                            </div>
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-foreground/70 mb-1">Description</label>
                            <textarea id="team-desc" rows="2" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm">${draft.description}</textarea>
                        </div>
                    </div>

                    <!-- Members List -->
                    <div class="space-y-3">
                        <div class="flex items-center justify-between">
                            <h3 class="font-serif text-lg font-bold text-foreground">Team Members (${draft.members.length})</h3>
                            <button id="team-add-member-btn" class="px-4 py-2 bg-forest-600 hover:bg-forest-700 text-white text-xs font-semibold rounded-xl transition shadow-soft">+ Add Member</button>
                        </div>

                        <div id="team-members-list" class="grid sm:grid-cols-2 gap-4">
                            ${draft.members.map((m, i) => `
                                <div class="p-4 bg-white rounded-2xl border border-earth-200 space-y-2.5 shadow-soft team-member-card">
                                    <div class="flex items-center justify-between">
                                        <span class="text-xs font-bold text-forest-700">Member #${i + 1}</span>
                                        <button class="member-del-btn text-xs text-red-500 hover:text-red-700 font-semibold" data-midx="${i}">Delete</button>
                                    </div>
                                    <input type="text" class="mem-name w-full px-3 py-1.5 rounded-lg border border-earth-200 text-xs font-bold" value="${m.name || ''}" placeholder="Full Name">
                                    <input type="text" class="mem-role w-full px-3 py-1.5 rounded-lg border border-earth-200 text-xs" value="${m.role || ''}" placeholder="Job Title / Role">
                                    <input type="text" class="mem-highlight w-full px-3 py-1.5 rounded-lg border border-earth-200 text-xs" value="${m.highlight || m.experience || ''}" placeholder="Highlight / Badge (e.g. 15+ yrs restoration)">
                                    <input type="text" class="mem-image w-full px-3 py-1.5 rounded-lg border border-earth-200 text-xs" value="${m.image || ''}" placeholder="Photo URL (optional)">
                                </div>
                            `).join('')}
                        </div>
                    </div>

                    <!-- Supporting Stats -->
                    <div class="space-y-3 pt-4 border-t border-earth-200">
                        <div class="flex items-center justify-between">
                            <h3 class="font-serif text-lg font-bold text-foreground">Bottom Statistics Cards (${draft.stats.length})</h3>
                            <button id="team-add-stat-btn" class="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold rounded-xl transition">+ Add Stat</button>
                        </div>
                        <div id="team-stats-list" class="grid sm:grid-cols-3 gap-3">
                            ${draft.stats.map((s, i) => `
                                <div class="p-3 bg-white rounded-2xl border border-earth-200 space-y-2 shadow-soft team-stat-card">
                                    <div class="flex items-center justify-between">
                                        <span class="text-[11px] font-semibold text-foreground/50">Stat #${i + 1}</span>
                                        <button class="stat-del-btn text-xs text-red-500 hover:text-red-700" data-sidx="${i}">✕</button>
                                    </div>
                                    <input type="text" class="stat-val w-full px-3 py-1.5 rounded-lg border border-earth-200 text-xs font-bold text-forest-700" value="${s.value || ''}" placeholder="Value (e.g. 100%)">
                                    <input type="text" class="stat-lbl w-full px-3 py-1.5 rounded-lg border border-earth-200 text-xs" value="${s.label || ''}" placeholder="Label">
                                </div>
                            `).join('')}
                        </div>
                    </div>

                    <!-- Save Actions -->
                    <div class="flex items-center gap-4 pt-4 border-t border-earth-200">
                        <button id="team-save-btn" class="px-6 py-2.5 bg-forest-600 hover:bg-forest-700 text-white font-semibold text-sm rounded-xl transition shadow-medium">Save Team Data</button>
                        <span id="team-save-status"></span>
                    </div>
                </div>
            `;

            // Add Member
            document.getElementById('team-add-member-btn').addEventListener('click', () => {
                draft.members.push({ name: 'New Team Member', role: 'Role / Specialist', highlight: 'Community lead', image: '' });
                drawTeamUI();
            });

            // Delete Member
            document.querySelectorAll('.member-del-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const idx = parseInt(this.getAttribute('data-midx'), 10);
                    draft.members.splice(idx, 1);
                    drawTeamUI();
                });
            });

            // Add Stat
            document.getElementById('team-add-stat-btn').addEventListener('click', () => {
                draft.stats.push({ value: '10+', label: 'New Metric' });
                drawTeamUI();
            });

            // Delete Stat
            document.querySelectorAll('.stat-del-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const idx = parseInt(this.getAttribute('data-sidx'), 10);
                    draft.stats.splice(idx, 1);
                    drawTeamUI();
                });
            });

            // Save Team
            document.getElementById('team-save-btn').addEventListener('click', async () => {
                draft.sectionTitle = document.getElementById('team-title').value.trim();
                draft.headline = document.getElementById('team-headline').value.trim();
                draft.description = document.getElementById('team-desc').value.trim();

                const memCards = document.querySelectorAll('.team-member-card');
                draft.members = [];
                memCards.forEach(card => {
                    draft.members.push({
                        name: card.querySelector('.mem-name').value.trim(),
                        role: card.querySelector('.mem-role').value.trim(),
                        highlight: card.querySelector('.mem-highlight').value.trim(),
                        experience: card.querySelector('.mem-highlight').value.trim(),
                        image: card.querySelector('.mem-image').value.trim()
                    });
                });

                const statCards = document.querySelectorAll('.team-stat-card');
                draft.stats = [];
                statCards.forEach(card => {
                    draft.stats.push({
                        value: card.querySelector('.stat-val').value.trim(),
                        label: card.querySelector('.stat-lbl').value.trim()
                    });
                });

                const res = await saveAdminData('team', draft);
                showToast('team-save-status', res.ok ? `Saved at ${res.savedAt || new Date().toLocaleTimeString()}!` : 'Error saving.', res.ok);
            });
        }

        drawTeamUI();
    }

    // =========================================================
    // 6. STORIES MODULE (Full 3 Chapters Editor)
    // =========================================================
    async function renderStories() {
        const data = await fetchAdminData('stories') || {
            seed: {
                chapter: 'Chapter One',
                title: 'It Starts With a Single Seed',
                body1: 'Beneath the soil, magic happens. A tiny seed holds the blueprint for a forest giant.',
                body2: 'With patience and care, life emerges.',
                badge: 'Day 1',
                subbadge: 'The beginning'
            },
            growth: {
                chapter: 'Chapter Two',
                title: 'Growing Through Adversity',
                body1: 'Young saplings brave harsh winds and summer heat.',
                body2: 'Careful irrigation and local stewardship protect vulnerable seedlings.',
                badge: 'Year 2',
                subbadge: 'Taking root'
            },
            mature: {
                chapter: 'Chapter Three',
                title: 'A Legacy That Lives On',
                body1: 'Decades later, a thriving canopy shelters diverse wildlife.',
                body2: 'Restored woodlands become gathering grounds and carbon sinks.',
                badge: 'Year 10+',
                subbadge: 'Thriving Forest'
            }
        };

        moduleContent.innerHTML = `
            <div class="space-y-6 animate-in fade-in">
                <div>
                    <h2 class="font-serif text-2xl font-bold text-foreground">Impact Story Chapters</h2>
                    <p class="text-xs sm:text-sm text-foreground/60">Configure the 3 interactive storytelling chapters on the Impact page.</p>
                </div>

                <div class="space-y-6">
                    <!-- Chapter 1: Seed -->
                    <div class="p-6 bg-white rounded-3xl border border-earth-200 space-y-4 shadow-soft">
                        <div class="flex items-center gap-2">
                            <span class="w-3 h-3 rounded-full bg-forest-600"></span>
                            <h3 class="font-serif text-lg font-bold text-foreground">Chapter 1: The Seed</h3>
                        </div>
                        <div class="grid sm:grid-cols-3 gap-3">
                            <input id="st-seed-chap" type="text" class="px-3 py-2 rounded-xl border border-earth-200 text-xs font-semibold" value="${data.seed?.chapter || 'Chapter One'}" placeholder="Chapter Label">
                            <input id="st-seed-badge" type="text" class="px-3 py-2 rounded-xl border border-earth-200 text-xs" value="${data.seed?.badge || 'Day 1'}" placeholder="Badge Text">
                            <input id="st-seed-subbadge" type="text" class="px-3 py-2 rounded-xl border border-earth-200 text-xs" value="${data.seed?.subbadge || 'The beginning'}" placeholder="Subbadge">
                        </div>
                        <input id="st-seed-title" type="text" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm font-semibold" value="${data.seed?.title || ''}" placeholder="Headline">
                        <textarea id="st-seed-b1" rows="2" class="w-full px-4 py-2 rounded-xl border border-earth-200 text-xs" placeholder="Paragraph 1">${data.seed?.body1 || ''}</textarea>
                        <textarea id="st-seed-b2" rows="2" class="w-full px-4 py-2 rounded-xl border border-earth-200 text-xs" placeholder="Paragraph 2">${data.seed?.body2 || ''}</textarea>
                    </div>

                    <!-- Chapter 2: Growth -->
                    <div class="p-6 bg-white rounded-3xl border border-earth-200 space-y-4 shadow-soft">
                        <div class="flex items-center gap-2">
                            <span class="w-3 h-3 rounded-full bg-forest-600"></span>
                            <h3 class="font-serif text-lg font-bold text-foreground">Chapter 2: Growth</h3>
                        </div>
                        <div class="grid sm:grid-cols-3 gap-3">
                            <input id="st-growth-chap" type="text" class="px-3 py-2 rounded-xl border border-earth-200 text-xs font-semibold" value="${data.growth?.chapter || 'Chapter Two'}" placeholder="Chapter Label">
                            <input id="st-growth-badge" type="text" class="px-3 py-2 rounded-xl border border-earth-200 text-xs" value="${data.growth?.badge || 'Year 2'}" placeholder="Badge Text">
                            <input id="st-growth-subbadge" type="text" class="px-3 py-2 rounded-xl border border-earth-200 text-xs" value="${data.growth?.subbadge || 'Taking root'}" placeholder="Subbadge">
                        </div>
                        <input id="st-growth-title" type="text" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm font-semibold" value="${data.growth?.title || ''}" placeholder="Headline">
                        <textarea id="st-growth-b1" rows="2" class="w-full px-4 py-2 rounded-xl border border-earth-200 text-xs" placeholder="Paragraph 1">${data.growth?.body1 || ''}</textarea>
                        <textarea id="st-growth-b2" rows="2" class="w-full px-4 py-2 rounded-xl border border-earth-200 text-xs" placeholder="Paragraph 2">${data.growth?.body2 || ''}</textarea>
                    </div>

                    <!-- Chapter 3: Mature -->
                    <div class="p-6 bg-white rounded-3xl border border-earth-200 space-y-4 shadow-soft">
                        <div class="flex items-center gap-2">
                            <span class="w-3 h-3 rounded-full bg-forest-600"></span>
                            <h3 class="font-serif text-lg font-bold text-foreground">Chapter 3: Mature Canopy</h3>
                        </div>
                        <div class="grid sm:grid-cols-3 gap-3">
                            <input id="st-mature-chap" type="text" class="px-3 py-2 rounded-xl border border-earth-200 text-xs font-semibold" value="${data.mature?.chapter || 'Chapter Three'}" placeholder="Chapter Label">
                            <input id="st-mature-badge" type="text" class="px-3 py-2 rounded-xl border border-earth-200 text-xs" value="${data.mature?.badge || 'Year 10+'}" placeholder="Badge Text">
                            <input id="st-mature-subbadge" type="text" class="px-3 py-2 rounded-xl border border-earth-200 text-xs" value="${data.mature?.subbadge || 'Thriving Forest'}" placeholder="Subbadge">
                        </div>
                        <input id="st-mature-title" type="text" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm font-semibold" value="${data.mature?.title || ''}" placeholder="Headline">
                        <textarea id="st-mature-b1" rows="2" class="w-full px-4 py-2 rounded-xl border border-earth-200 text-xs" placeholder="Paragraph 1">${data.mature?.body1 || ''}</textarea>
                        <textarea id="st-mature-b2" rows="2" class="w-full px-4 py-2 rounded-xl border border-earth-200 text-xs" placeholder="Paragraph 2">${data.mature?.body2 || ''}</textarea>
                    </div>
                </div>

                <div class="flex items-center gap-4 pt-4 border-t border-earth-200">
                    <button id="stories-save-btn" class="px-6 py-2.5 bg-forest-600 hover:bg-forest-700 text-white font-semibold text-sm rounded-xl transition shadow-medium">Save Stories</button>
                    <span id="stories-save-status"></span>
                </div>
            </div>
        `;

        document.getElementById('stories-save-btn').addEventListener('click', async () => {
            const nextStories = {
                seed: {
                    chapter: document.getElementById('st-seed-chap').value.trim(),
                    badge: document.getElementById('st-seed-badge').value.trim(),
                    subbadge: document.getElementById('st-seed-subbadge').value.trim(),
                    title: document.getElementById('st-seed-title').value.trim(),
                    body1: document.getElementById('st-seed-b1').value.trim(),
                    body2: document.getElementById('st-seed-b2').value.trim()
                },
                growth: {
                    chapter: document.getElementById('st-growth-chap').value.trim(),
                    badge: document.getElementById('st-growth-badge').value.trim(),
                    subbadge: document.getElementById('st-growth-subbadge').value.trim(),
                    title: document.getElementById('st-growth-title').value.trim(),
                    body1: document.getElementById('st-growth-b1').value.trim(),
                    body2: document.getElementById('st-growth-b2').value.trim()
                },
                mature: {
                    chapter: document.getElementById('st-mature-chap').value.trim(),
                    badge: document.getElementById('st-mature-badge').value.trim(),
                    subbadge: document.getElementById('st-mature-subbadge').value.trim(),
                    title: document.getElementById('st-mature-title').value.trim(),
                    body1: document.getElementById('st-mature-b1').value.trim(),
                    body2: document.getElementById('st-mature-b2').value.trim()
                }
            };
            const res = await saveAdminData('stories', nextStories);
            showToast('stories-save-status', res.ok ? `Saved at ${res.savedAt || new Date().toLocaleTimeString()}!` : 'Error saving.', res.ok);
        });
    }

    // =========================================================
    // 7. FAQ MODULE (Full CRUD)
    // =========================================================
    async function renderFaq() {
        const raw = await fetchAdminData('faq') || {};
        const faqs = Array.isArray(raw.faqs) ? raw.faqs : (Array.isArray(raw) ? raw : []);

        function drawFaqUI() {
            moduleContent.innerHTML = `
                <div class="space-y-6 animate-in fade-in">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="font-serif text-2xl font-bold text-foreground">FAQ Management (${faqs.length})</h2>
                            <p class="text-xs sm:text-sm text-foreground/60">Frequently asked questions shown on the FAQ page and widget.</p>
                        </div>
                        <button id="faq-add-btn" class="px-4 py-2 bg-forest-600 hover:bg-forest-700 text-white text-xs font-semibold rounded-xl transition shadow-soft">+ Add Question</button>
                    </div>

                    <div id="faq-items-list" class="space-y-4">
                        ${faqs.map((f, i) => `
                            <div class="p-4 bg-white rounded-2xl border border-earth-200 space-y-2 faq-admin-card shadow-soft" data-index="${i}">
                                <div class="flex items-center justify-between">
                                    <label class="text-xs font-bold text-forest-700">Question #${i + 1}</label>
                                    <button class="faq-del-btn text-xs text-red-500 hover:text-red-700 font-semibold" data-index="${i}">Delete</button>
                                </div>
                                <input type="text" class="faq-q-input w-full px-4 py-2 rounded-xl border border-earth-200 text-sm font-semibold" value="${f.q || ''}" placeholder="Question Title">
                                <textarea rows="2" class="faq-a-input w-full px-4 py-2 rounded-xl border border-earth-200 text-xs text-foreground/80 leading-relaxed" placeholder="Answer Explanation">${f.a || ''}</textarea>
                            </div>
                        `).join('')}
                    </div>

                    <div class="flex items-center gap-4 pt-4 border-t border-earth-200">
                        <button id="faq-save-btn" class="px-6 py-2.5 bg-forest-600 hover:bg-forest-700 text-white font-semibold text-sm rounded-xl transition shadow-medium">Save FAQs</button>
                        <span id="faq-status"></span>
                    </div>
                </div>
            `;

            document.getElementById('faq-add-btn').addEventListener('click', () => {
                faqs.push({ q: 'New question title', a: 'Answer description goes here.' });
                drawFaqUI();
            });

            document.querySelectorAll('.faq-del-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const idx = parseInt(this.getAttribute('data-index'), 10);
                    faqs.splice(idx, 1);
                    drawFaqUI();
                });
            });

            document.getElementById('faq-save-btn').addEventListener('click', async () => {
                const cards = document.querySelectorAll('.faq-admin-card');
                const updatedFaqs = [];
                cards.forEach(card => {
                    const q = card.querySelector('.faq-q-input').value.trim();
                    const a = card.querySelector('.faq-a-input').value.trim();
                    if (q) updatedFaqs.push({ q, a });
                });
                const res = await saveAdminData('faq', { faqs: updatedFaqs });
                showToast('faq-status', res.ok ? `Saved at ${res.savedAt || new Date().toLocaleTimeString()}!` : 'Error saving.', res.ok);
            });
        }

        drawFaqUI();
    }

    // =========================================================
    // 8. DISCLAIMER MODULE
    // =========================================================
    async function renderDisclaimer() {
        const data = await fetchAdminData('disclaimer') || {
            enabled: true,
            message: '🌳 OneMoreTree NGO is a volunteer-led initiative. All donations go directly to tree planting, site restoration, and community programs.'
        };

        moduleContent.innerHTML = `
            <div class="space-y-6 animate-in fade-in">
                <div>
                    <h2 class="font-serif text-2xl font-bold text-foreground">Top Disclaimer Ribbon</h2>
                    <p class="text-xs sm:text-sm text-foreground/60">Configures the site-wide notification bar at the top of every page.</p>
                </div>
                <div class="p-6 bg-white rounded-3xl border border-earth-200 space-y-4 shadow-soft">
                    <label class="flex items-center gap-3 cursor-pointer">
                        <input id="disc-enabled" type="checkbox" class="w-5 h-5 rounded text-forest-600 focus:ring-forest-500" ${data.enabled ? 'checked' : ''}>
                        <span class="text-sm font-semibold text-foreground">Display ribbon on live website</span>
                    </label>
                    <div>
                        <label class="block text-xs font-semibold text-foreground/70 mb-1">Banner Message</label>
                        <textarea id="disc-msg" rows="3" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm focus:border-forest-500 outline-none">${data.message || ''}</textarea>
                    </div>
                </div>
                <div class="flex items-center gap-4 pt-4 border-t border-earth-200">
                    <button id="disc-save-btn" class="px-6 py-2.5 bg-forest-600 hover:bg-forest-700 text-white font-semibold text-sm rounded-xl transition shadow-medium">Save Disclaimer</button>
                    <span id="disc-status"></span>
                </div>
            </div>
        `;

        document.getElementById('disc-save-btn').addEventListener('click', async () => {
            const next = {
                enabled: document.getElementById('disc-enabled').checked,
                message: document.getElementById('disc-msg').value.trim()
            };
            const res = await saveAdminData('disclaimer', next);
            showToast('disc-status', res.ok ? `Saved at ${res.savedAt || new Date().toLocaleTimeString()}!` : 'Error saving.', res.ok);
        });
    }

    // =========================================================
    // 9. DONATIONS MODULE (Tiers & Orders)
    // =========================================================
    async function renderDonations() {
        const raw = await fetchAdminData('donation_tiers') || {};
        const tiers = Array.isArray(raw.tiers) ? raw.tiers : [
            { amount: 25, title: '$25 support', description: 'Supports tree planting, site care, and local communities.', trees: 75, volunteers: 3 },
            { amount: 50, title: '$50 support', description: 'Expands native tree coverage and regional biodiversity.', trees: 150, volunteers: 5 },
            { amount: 100, title: '$100 support', description: 'Funds full plot restoration, native saplings, and 5-year monitoring.', trees: 300, volunteers: 10 }
        ];

        function drawDonationsUI() {
            moduleContent.innerHTML = `
                <div class="space-y-6 animate-in fade-in">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="font-serif text-2xl font-bold text-foreground">Donation Tiers & 3D Multipliers</h2>
                            <p class="text-xs sm:text-sm text-foreground/60">Configure presets, multiplier calculations, and descriptions shown on the 3D card.</p>
                        </div>
                        <button id="dt-add-btn" class="px-4 py-2 bg-forest-600 hover:bg-forest-700 text-white text-xs font-semibold rounded-xl transition shadow-soft">+ Add Tier</button>
                    </div>

                    <div id="donation-tiers-grid" class="grid gap-4 sm:grid-cols-3">
                        ${tiers.map((t, i) => `
                            <div class="p-5 bg-white rounded-3xl border border-earth-200 space-y-3 shadow-soft dt-tier-card" data-tidx="${i}">
                                <div class="flex items-center justify-between">
                                    <span class="text-xs uppercase font-bold text-forest-700">Tier #${i + 1}</span>
                                    <button class="dt-del-btn text-xs text-red-500 hover:text-red-700 font-semibold" data-tidx="${i}">Delete</button>
                                </div>
                                <div>
                                    <label class="block text-[11px] font-semibold text-foreground/60 mb-1">Amount ($)</label>
                                    <input type="number" class="dt-amount w-full px-3 py-1.5 rounded-lg border border-earth-200 text-sm font-bold text-foreground" value="${t.amount}">
                                </div>
                                <div class="grid grid-cols-2 gap-2">
                                    <div>
                                        <label class="block text-[10px] font-semibold text-foreground/60 mb-1">Trees</label>
                                        <input type="number" class="dt-trees w-full px-3 py-1.5 rounded-lg border border-earth-200 text-xs" value="${t.trees}">
                                    </div>
                                    <div>
                                        <label class="block text-[10px] font-semibold text-foreground/60 mb-1">Volunteers</label>
                                        <input type="number" class="dt-volunteers w-full px-3 py-1.5 rounded-lg border border-earth-200 text-xs" value="${t.volunteers}">
                                    </div>
                                </div>
                                <div>
                                    <label class="block text-[11px] font-semibold text-foreground/60 mb-1">Description</label>
                                    <textarea rows="2" class="dt-desc w-full px-3 py-1.5 rounded-lg border border-earth-200 text-xs">${t.description || ''}</textarea>
                                </div>
                            </div>
                        `).join('')}
                    </div>

                    <div class="flex items-center gap-4 pt-4 border-t border-earth-200">
                        <button id="dt-save-btn" class="px-6 py-2.5 bg-forest-600 hover:bg-forest-700 text-white font-semibold text-sm rounded-xl transition shadow-medium">Save Donation Tiers</button>
                        <span id="dt-status"></span>
                    </div>
                </div>
            `;

            document.getElementById('dt-add-btn').addEventListener('click', () => {
                tiers.push({ amount: 200, title: '$200 support', description: 'Supports extensive forest recovery.', trees: 600, volunteers: 20 });
                drawDonationsUI();
            });

            document.querySelectorAll('.dt-del-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const idx = parseInt(this.getAttribute('data-tidx'), 10);
                    tiers.splice(idx, 1);
                    drawDonationsUI();
                });
            });

            document.getElementById('dt-save-btn').addEventListener('click', async () => {
                const cards = document.querySelectorAll('.dt-tier-card');
                const nextTiers = [];
                cards.forEach(card => {
                    const amt = parseInt(card.querySelector('.dt-amount').value, 10) || 25;
                    nextTiers.push({
                        amount: amt,
                        title: `$${amt} support`,
                        trees: parseInt(card.querySelector('.dt-trees').value, 10) || 0,
                        volunteers: parseInt(card.querySelector('.dt-volunteers').value, 10) || 0,
                        description: card.querySelector('.dt-desc').value.trim()
                    });
                });
                const res = await saveAdminData('donation_tiers', { tiers: nextTiers });
                showToast('dt-status', res.ok ? `Saved at ${res.savedAt || new Date().toLocaleTimeString()}!` : 'Error saving.', res.ok);
            });
        }

        drawDonationsUI();
    }

    // =========================================================
    // 10. SOCIAL MEDIA MODULE
    // =========================================================
    async function renderSocialMedia() {
        const data = await fetchAdminData('social') || {
            instagram: 'https://instagram.com/onemoretree',
            twitter: 'https://twitter.com/onemoretree',
            facebook: 'https://facebook.com/onemoretree',
            linkedin: 'https://linkedin.com/company/onemoretree'
        };

        moduleContent.innerHTML = `
            <div class="space-y-6 animate-in fade-in">
                <div>
                    <h2 class="font-serif text-2xl font-bold text-foreground">Social Media Links</h2>
                    <p class="text-xs sm:text-sm text-foreground/60">Social links displayed across the website header, footer, and contact cards.</p>
                </div>
                <div class="p-6 bg-white rounded-3xl border border-earth-200 space-y-4 shadow-soft">
                    <div>
                        <label class="block text-xs font-semibold text-foreground/70 mb-1">Instagram URL</label>
                        <input id="soc-ig" type="url" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm focus:border-forest-500 outline-none" value="${data.instagram || ''}">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-foreground/70 mb-1">Twitter / X URL</label>
                        <input id="soc-tw" type="url" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm focus:border-forest-500 outline-none" value="${data.twitter || ''}">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-foreground/70 mb-1">Facebook URL</label>
                        <input id="soc-fb" type="url" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm focus:border-forest-500 outline-none" value="${data.facebook || ''}">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-foreground/70 mb-1">LinkedIn URL</label>
                        <input id="soc-li" type="url" class="w-full px-4 py-2.5 rounded-xl border border-earth-200 text-sm focus:border-forest-500 outline-none" value="${data.linkedin || ''}">
                    </div>
                </div>
                <div class="flex items-center gap-4 pt-4 border-t border-earth-200">
                    <button id="soc-save-btn" class="px-6 py-2.5 bg-forest-600 hover:bg-forest-700 text-white font-semibold text-sm rounded-xl transition shadow-medium">Save Social Links</button>
                    <span id="soc-status"></span>
                </div>
            </div>
        `;

        document.getElementById('soc-save-btn').addEventListener('click', async () => {
            const next = {
                instagram: document.getElementById('soc-ig').value.trim(),
                twitter: document.getElementById('soc-tw').value.trim(),
                facebook: document.getElementById('soc-fb').value.trim(),
                linkedin: document.getElementById('soc-li').value.trim()
            };
            const res = await saveAdminData('social', next);
            showToast('soc-status', res.ok ? `Saved at ${res.savedAt || new Date().toLocaleTimeString()}!` : 'Error saving.', res.ok);
        });
    }

    // =========================================================
    // 11. CONTACT INQUIRIES MODULE (List + Delete + Export)
    // =========================================================
    async function renderContact() {
        const list = await fetchAdminData('contact_submissions', true) || [];

        function drawContactUI() {
            moduleContent.innerHTML = `
                <div class="space-y-6 animate-in fade-in">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="font-serif text-2xl font-bold text-foreground">Contact Form Inquiries (${list.length})</h2>
                            <p class="text-xs sm:text-sm text-foreground/60">Submissions received through the contact and volunteer forms.</p>
                        </div>
                        ${list.length > 0 ? `
                            <button id="export-contact-btn" class="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold rounded-xl transition">
                                ⬇ Export CSV
                            </button>
                        ` : ''}
                    </div>

                    ${list.length === 0 ? `
                        <div class="p-12 text-center bg-white rounded-3xl border border-earth-200 text-foreground/50 text-sm">
                            <p>No contact submissions recorded yet.</p>
                            <p class="text-xs text-foreground/40 mt-1">When users send messages via the Contact or Get Involved forms, they will appear here.</p>
                        </div>
                    ` : `
                        <div class="space-y-3">
                            ${list.map((sub, i) => `
                                <div class="p-5 bg-white rounded-2xl border border-earth-200 space-y-2 shadow-soft">
                                    <div class="flex items-center justify-between">
                                        <div class="flex items-center gap-3">
                                            <span class="font-serif font-bold text-sm text-foreground">${sub.name || 'Anonymous'}</span>
                                            <span class="text-xs text-forest-700 bg-forest-50 border border-forest-200 px-2 py-0.5 rounded-full font-medium">${sub.interest || 'Inquiry'}</span>
                                        </div>
                                        <div class="flex items-center gap-3">
                                            <span class="text-xs text-foreground/40">${sub.date || ''}</span>
                                            <button class="sub-del-btn text-xs text-red-500 hover:text-red-700 font-semibold" data-sidx="${i}">Delete</button>
                                        </div>
                                    </div>
                                    <div class="text-xs font-medium text-forest-600">${sub.email || ''}</div>
                                    <div class="text-xs text-foreground/80 pt-1 leading-relaxed bg-slate-50 p-3 rounded-xl border border-earth-100">${sub.message || ''}</div>
                                </div>
                            `).join('')}
                        </div>
                    `}
                </div>
            `;

            document.querySelectorAll('.sub-del-btn').forEach(btn => {
                btn.addEventListener('click', async function() {
                    const idx = parseInt(this.getAttribute('data-sidx'), 10);
                    if (confirm('Delete this contact inquiry?')) {
                        list.splice(idx, 1);
                        await saveAdminData('contact_submissions', list);
                        drawContactUI();
                    }
                });
            });

            const exportBtn = document.getElementById('export-contact-btn');
            if (exportBtn) {
                exportBtn.addEventListener('click', () => {
                    let csv = 'Name,Email,Interest,Date,Message\n';
                    list.forEach(s => {
                        csv += `"${(s.name||'').replace(/"/g, '""')}","${(s.email||'').replace(/"/g, '""')}","${(s.interest||'').replace(/"/g, '""')}","${(s.date||'').replace(/"/g, '""')}","${(s.message||'').replace(/"/g, '""')}"\n`;
                    });
                    const blob = new Blob([csv], { type: 'text/csv' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `onemoretree-contacts-${new Date().toISOString().slice(0,10)}.csv`;
                    a.click();
                });
            }
        }

        drawContactUI();
    }

    // =========================================================
    // 12. NEWSLETTER MODULE (List + Delete + Export)
    // =========================================================
    async function renderNewsletter() {
        const list = await fetchAdminData('newsletter_subscribers', true) || [];

        function drawNewsletterUI() {
            moduleContent.innerHTML = `
                <div class="space-y-6 animate-in fade-in">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="font-serif text-2xl font-bold text-foreground">Newsletter Subscribers (${list.length})</h2>
                            <p class="text-xs sm:text-sm text-foreground/60">Subscribers registered via website newsletter forms.</p>
                        </div>
                        ${list.length > 0 ? `
                            <button id="export-nl-btn" class="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold rounded-xl transition">
                                ⬇ Export CSV
                            </button>
                        ` : ''}
                    </div>

                    ${list.length === 0 ? `
                        <div class="p-12 text-center bg-white rounded-3xl border border-earth-200 text-foreground/50 text-sm">
                            <p>No subscribers registered yet.</p>
                            <p class="text-xs text-foreground/40 mt-1">When users sign up for updates in the footer or blog, their emails will show here.</p>
                        </div>
                    ` : `
                        <div class="bg-white rounded-3xl border border-earth-200 divide-y divide-earth-100 overflow-hidden shadow-soft">
                            ${list.map((s, i) => `
                                <div class="p-4 flex items-center justify-between text-xs hover:bg-slate-50 transition">
                                    <div class="flex items-center gap-3">
                                        <span class="w-2 h-2 rounded-full bg-forest-500"></span>
                                        <span class="font-semibold text-foreground text-sm">${s.email}</span>
                                    </div>
                                    <div class="flex items-center gap-4">
                                        <span class="text-foreground/40">${s.date || ''}</span>
                                        <button class="nl-del-btn text-xs text-red-500 hover:text-red-700 font-semibold" data-nlidx="${i}">Delete</button>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    `}
                </div>
            `;

            document.querySelectorAll('.nl-del-btn').forEach(btn => {
                btn.addEventListener('click', async function() {
                    const idx = parseInt(this.getAttribute('data-nlidx'), 10);
                    if (confirm('Remove this email from subscribers?')) {
                        list.splice(idx, 1);
                        await saveAdminData('newsletter_subscribers', list);
                        drawNewsletterUI();
                    }
                });
            });

            const exportBtn = document.getElementById('export-nl-btn');
            if (exportBtn) {
                exportBtn.addEventListener('click', () => {
                    let csv = 'Email,Date\n';
                    list.forEach(s => {
                        csv += `"${(s.email||'').replace(/"/g, '""')}","${(s.date||'').replace(/"/g, '""')}"\n`;
                    });
                    const blob = new Blob([csv], { type: 'text/csv' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `onemoretree-subscribers-${new Date().toISOString().slice(0,10)}.csv`;
                    a.click();
                });
            }
        }

        drawNewsletterUI();
    }

    // =========================================================
    // 13. MODULE VISIBILITY STATUS
    // =========================================================
    async function renderModuleStatus() {
        const data = await fetchAdminData('modules') || {
            home_hero: true,
            home_counters: true,
            home_story: true,
            home_donation: true,
            home_testimonials: true,
            live_map: true,
            impact_story: true,
            faq_section: true
        };

        moduleContent.innerHTML = `
            <div class="space-y-6 animate-in fade-in">
                <div>
                    <h2 class="font-serif text-2xl font-bold text-foreground">Module Visibility & Toggles</h2>
                    <p class="text-xs sm:text-sm text-foreground/60">Instantly show or hide specific website sections and public widgets.</p>
                </div>
                <div class="grid gap-3 sm:grid-cols-2">
                    ${Object.keys(data).map(key => `
                        <div class="p-4 bg-white rounded-2xl border border-earth-200 flex items-center justify-between shadow-soft">
                            <div>
                                <span class="text-sm font-semibold text-foreground capitalize">${key.replace(/_/g, ' ')}</span>
                                <p class="text-[11px] text-foreground/40">Controls live section display</p>
                            </div>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" class="mod-status-toggle sr-only peer" data-key="${key}" ${data[key] ? 'checked' : ''}>
                                <div class="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-forest-600"></div>
                            </label>
                        </div>
                    `).join('')}
                </div>
                <div class="flex items-center gap-4 pt-4 border-t border-earth-200">
                    <button id="mod-save-btn" class="px-6 py-2.5 bg-forest-600 hover:bg-forest-700 text-white font-semibold text-sm rounded-xl transition shadow-medium">Save Module Visibility</button>
                    <span id="mod-status"></span>
                </div>
            </div>
        `;

        document.getElementById('mod-save-btn').addEventListener('click', async () => {
            const next = {};
            document.querySelectorAll('.mod-status-toggle').forEach(chk => {
                const k = chk.getAttribute('data-key');
                next[k] = chk.checked;
            });
            const res = await saveAdminData('modules', next);
            showToast('mod-status', res.ok ? `Saved at ${res.savedAt || new Date().toLocaleTimeString()}!` : 'Error saving.', res.ok);
        });
    }

    // =========================================================
    // 14. ADMIN USERS MODULE
    // =========================================================
    async function renderAdminUsers() {
        moduleContent.innerHTML = `
            <div class="space-y-6 animate-in fade-in">
                <div class="flex items-center justify-between">
                    <div>
                        <h2 class="font-serif text-2xl font-bold text-foreground">System Users & Authentication</h2>
                        <p class="text-xs sm:text-sm text-foreground/60">Unified authentication: manage system administrators and roles.</p>
                    </div>
                    <a href="${config.siteUrl}wp-admin/user-new.php" target="_blank" class="px-4 py-2 bg-forest-600 hover:bg-forest-700 text-white text-xs font-semibold rounded-xl transition shadow-soft flex items-center gap-1.5">
                        <span>+ Add New User</span>
                    </a>
                </div>

                <div class="p-6 bg-white rounded-3xl border border-earth-200 space-y-4 shadow-soft">
                    <div class="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-earth-100">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-forest-600 text-white flex items-center justify-center font-serif font-bold text-sm">
                                ${(config.username || 'A')[0].toUpperCase()}
                            </div>
                            <div>
                                <div class="font-bold text-sm text-foreground">${config.displayName || config.username}</div>
                                <div class="text-xs text-foreground/50">Username: ${config.username} • Administrator</div>
                            </div>
                        </div>
                        <span class="text-xs font-semibold text-forest-700 bg-forest-100 px-3 py-1 rounded-full">Current Session</span>
                    </div>

                    <p class="text-xs text-foreground/60 pt-2">
                        All administrator accounts use standard WordPress secure password hashing (phpass/bcrypt) with nonce verification and REST protection. Any user with <code>manage_options</code> or <code>edit_posts</code> role can log into both <code>/administrator</code> and <code>/wp-admin</code>.
                    </p>

                    <div class="flex gap-3 pt-2">
                        <a href="${config.siteUrl}wp-admin/users.php" target="_blank" class="px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold rounded-xl transition">
                            Manage All Users in WordPress →
                        </a>
                    </div>
                </div>
            </div>
        `;
    }

    // =========================================================
    // 15. BLOG ARTICLES MODULE
    // =========================================================
    async function renderBlog() {
        moduleContent.innerHTML = `
            <div class="space-y-6 animate-in fade-in">
                <div class="flex items-center justify-between">
                    <div>
                        <h2 class="font-serif text-2xl font-bold text-foreground">Blog Articles & Stories</h2>
                        <p class="text-xs sm:text-sm text-foreground/60">Manage published articles, ecology stories, and news updates.</p>
                    </div>
                    <a href="${config.siteUrl}wp-admin/post-new.php" target="_blank" class="px-4 py-2 bg-forest-600 hover:bg-forest-700 text-white text-xs font-semibold rounded-xl transition shadow-soft flex items-center gap-1.5">
                        <span>+ Write New Post</span>
                    </a>
                </div>

                <div class="p-6 bg-white rounded-3xl border border-earth-200 space-y-4 shadow-soft">
                    <p class="text-sm text-foreground/70 leading-relaxed">
                        Blog posts use WordPress's native post system. You can create rich Gutenberg articles, upload featured images, assign categories and tags, and preview them live on the public blog.
                    </p>
                    <div class="flex gap-3 pt-2">
                        <a href="${config.siteUrl}wp-admin/edit.php" target="_blank" class="px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold rounded-xl transition">
                            Open Post Editor in WordPress →
                        </a>
                        <a href="${config.siteUrl}blog" target="_blank" class="px-4 py-2.5 bg-forest-50 hover:bg-forest-100 text-forest-700 border border-forest-200 text-xs font-semibold rounded-xl transition">
                            View Public Blog →
                        </a>
                    </div>
                </div>
            </div>
        `;
    }

    // =========================================================
    // 16. REPORTING & ANALYTICS MODULE
    // =========================================================
    async function renderReporting() {
        const counters = await fetchAdminData('home_counters') || { treesTracked: 1000000, projectsActive: 50, volunteersEngaged: 10000, regionsCovered: 4 };
        const contacts = await fetchAdminData('contact_submissions') || [];
        const newsletters = await fetchAdminData('newsletter_subscribers') || [];

        moduleContent.innerHTML = `
            <div class="space-y-6 animate-in fade-in">
                <div>
                    <h2 class="font-serif text-2xl font-bold text-foreground">System Analytics & Health Status</h2>
                    <p class="text-xs sm:text-sm text-foreground/60">Live metrics across tree tracking, community mobilization, inquiries, and server health.</p>
                </div>

                <!-- KPI Metric Cards -->
                <div class="grid gap-4 sm:grid-cols-3">
                    <div class="p-6 bg-white rounded-3xl border border-earth-200 text-center shadow-soft">
                        <div class="text-xs text-foreground/50 uppercase font-semibold mb-1 tracking-wider">Trees Tracked</div>
                        <div class="font-serif text-4xl font-bold text-forest-600">${(counters.treesTracked || 1000000).toLocaleString()}</div>
                        <div class="text-xs text-foreground/40 mt-1">Across Spain restoration sites</div>
                    </div>
                    <div class="p-6 bg-white rounded-3xl border border-earth-200 text-center shadow-soft">
                        <div class="text-xs text-foreground/50 uppercase font-semibold mb-1 tracking-wider">Active Volunteers</div>
                        <div class="font-serif text-4xl font-bold text-forest-600">${(counters.volunteersEngaged || 10000).toLocaleString()}</div>
                        <div class="text-xs text-foreground/40 mt-1">Community participants</div>
                    </div>
                    <div class="p-6 bg-white rounded-3xl border border-earth-200 text-center shadow-soft">
                        <div class="text-xs text-foreground/50 uppercase font-semibold mb-1 tracking-wider">Newsletter Subscribers</div>
                        <div class="font-serif text-4xl font-bold text-forest-600">${newsletters.length}</div>
                        <div class="text-xs text-foreground/40 mt-1">Registered supporters</div>
                    </div>
                </div>

                <!-- Health & System Info -->
                <div class="p-6 bg-white rounded-3xl border border-earth-200 space-y-4 shadow-soft">
                    <h3 class="font-serif text-lg font-bold text-foreground">System Health & Database Status</h3>
                    <div class="grid sm:grid-cols-2 gap-3 text-xs">
                        <div class="p-3.5 bg-slate-50 rounded-xl border border-earth-100 flex items-center justify-between">
                            <span class="text-foreground/70">REST API Backend</span>
                            <span class="font-semibold text-forest-700 bg-forest-100 px-2 py-0.5 rounded">Operational (200 OK)</span>
                        </div>
                        <div class="p-3.5 bg-slate-50 rounded-xl border border-earth-100 flex items-center justify-between">
                            <span class="text-foreground/70">Database Persistence</span>
                            <span class="font-semibold text-forest-700 bg-forest-100 px-2 py-0.5 rounded">MySQL Active</span>
                        </div>
                        <div class="p-3.5 bg-slate-50 rounded-xl border border-earth-100 flex items-center justify-between">
                            <span class="text-foreground/70">Authentication Bridge</span>
                            <span class="font-semibold text-forest-700 bg-forest-100 px-2 py-0.5 rounded">Unified WP Nonce</span>
                        </div>
                        <div class="p-3.5 bg-slate-50 rounded-xl border border-earth-100 flex items-center justify-between">
                            <span class="text-foreground/70">Public Content Cache</span>
                            <span class="font-semibold text-forest-700 bg-forest-100 px-2 py-0.5 rounded">Auto-Synced</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Initialize nav and default module
    renderNav();
    loadAndRenderActiveModule();
})();
