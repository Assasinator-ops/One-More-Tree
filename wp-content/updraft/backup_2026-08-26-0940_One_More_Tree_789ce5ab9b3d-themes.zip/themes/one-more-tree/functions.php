<?php
/**
 * One More Tree functions and definitions
 *
 * @package One_More_Tree
 */

if (!defined('_S_VERSION')) {
    define('_S_VERSION', '1.0.0');
}

/**
 * Theme setup
 */
function one_more_tree_setup() {
    // Add default posts and comments RSS feed links to head
    add_theme_support('automatic-feed-links');

    // Let WordPress manage the document title
    add_theme_support('title-tag');

    // Enable support for Post Thumbnails on posts and pages
    add_theme_support('post-thumbnails');

    // Enable wide and full-width block alignment
    add_theme_support('align-wide');

    // Enable responsive embedded content (YouTube, Vimeo, etc.)
    add_theme_support('responsive-embeds');

    // Enable core block styles and custom editor stylesheet
    add_theme_support('wp-block-styles');
    add_theme_support('editor-styles');
    add_editor_style([
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap',
        'assets/css/editor-style.css'
    ]);

    // Register navigation menus
    register_nav_menus([
        'primary' => __('Primary Menu', 'one-more-tree'),
        'footer'   => __('Footer Menu', 'one-more-tree'),
    ]);

    // Switch default core markup for search form, comment form, and comments
    add_theme_support('html5', [
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ]);

    // Add theme support for selective refresh for widgets
    add_theme_support('customize-selective-refresh-widgets');

    // Add support for core custom logo
    add_theme_support('custom-logo', [
        'height'      => 100,
        'width'       => 400,
        'flex-width'  => true,
        'flex-height' => true,
    ]);
}
add_action('after_setup_theme', 'one_more_tree_setup');

/**
 * Set the content width in pixels
 */
function one_more_tree_content_width() {
    $GLOBALS['content_width'] = apply_filters('one_more_tree_content_width', 1200);
}
add_action('after_setup_theme', 'one_more_tree_content_width', 0);

/**
 * Enqueue scripts and styles
 */
function one_more_tree_scripts() {
    // Enqueue compiled Tailwind CSS
    wp_enqueue_style(
        'one-more-tree-style',
        get_template_directory_uri() . '/assets/css/main.css',
        [],
        _S_VERSION
    );

    // Enqueue Gutenberg Native Block Styles matching Next.js design
    wp_enqueue_style(
        'one-more-tree-blocks',
        get_template_directory_uri() . '/assets/css/blocks.css',
        ['one-more-tree-style'],
        _S_VERSION
    );

    // Enqueue Google Fonts
    wp_enqueue_style(
        'one-more-tree-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap',
        [],
        null
    );

    // Remove WordPress emoji
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_print_styles', 'print_emoji_styles');
}
add_action('wp_enqueue_scripts', 'one_more_tree_scripts', 100);

/**
 * Remove WordPress default actions that add unwanted styles
 */
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wp_shortlink_wp_head');

/**
 * Enqueue JavaScript for interactivity
 */
function one_more_tree_scripts_js() {
    wp_enqueue_script(
        'one-more-tree-js',
        get_template_directory_uri() . '/assets/js/main.js',
        [],
        _S_VERSION,
        true
    );

    wp_localize_script('one-more-tree-js', 'OMT_CONFIG', [
        'restUrl'   => esc_url_raw(rest_url('omt/v1/')),
        'restNonce' => wp_create_nonce('wp_rest'),
    ]);
}
add_action('wp_enqueue_scripts', 'one_more_tree_scripts_js');

/**
 * Custom template tags for this theme
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * ACF Fields for homepage and page content management
 */
require get_template_directory() . '/inc/acf-fields.php';

/**
 * REST API endpoints for Next.js admin console and public forms
 */
require get_template_directory() . '/inc/admin-api.php';

/**
 * Native WordPress Admin Settings and Management Pages
 */
require get_template_directory() . '/inc/wp-admin-settings.php';

/**
 * Gutenberg Block Patterns
 */
require get_template_directory() . '/inc/block-patterns.php';

/**
 * Add page template support
 */
function one_more_tree_page_templates() {
    return [
        'front-page.php'            => 'Homepage Template',
        'template-full-width.php'   => 'Full Width (Block Canvas)',
        'template-contained.php'    => 'Contained / Editorial Document',
        'page-about.php'            => 'About Page Template',
        'page-projects.php'         => 'Projects Page Template',
        'page-impact.php'           => 'Impact Page Template',
        'page-faq.php'              => 'FAQ Page Template',
        'page-get-involved.php'     => 'Get Involved Page Template',
        'page-volunteer.php'        => 'Volunteer Page Template',
        'page-contact.php'          => 'Contact Page Template',
        'page-donate.php'           => 'Donate Page Template',
    ];
}
add_filter('theme_page_templates', 'one_more_tree_page_templates');

/**
 * Rewrite rules for Next.js Administrator console at /administrator and /admin
 */
function one_more_tree_admin_rewrite_rules() {
    add_rewrite_rule('^administrator/?$', 'index.php?omt_administrator=1', 'top');
    add_rewrite_rule('^admin/?$', 'index.php?omt_administrator=1', 'top');
}
add_action('init', 'one_more_tree_admin_rewrite_rules');

function one_more_tree_query_vars($vars) {
    $vars[] = 'omt_administrator';
    return $vars;
}
add_filter('query_vars', 'one_more_tree_query_vars');

function one_more_tree_admin_template_redirect() {
    if (get_query_var('omt_administrator')) {
        require get_template_directory() . '/inc/administrator-view.php';
        exit;
    }
}
add_action('template_redirect', 'one_more_tree_admin_template_redirect');

/**
 * Automatically create and configure essential pages on theme setup
 */
function one_more_tree_provision_default_pages() {
    $pages = [
        [
            'title'    => 'Home',
            'slug'     => 'home',
            'template' => 'front-page.php',
        ],
        [
            'title'    => 'About',
            'slug'     => 'about',
            'template' => 'page-about.php',
        ],
        [
            'title'    => 'Projects',
            'slug'     => 'projects',
            'template' => 'page-projects.php',
        ],
        [
            'title'    => 'Impact',
            'slug'     => 'impact',
            'template' => 'page-impact.php',
        ],
        [
            'title'    => 'FAQ',
            'slug'     => 'faq',
            'template' => 'page-faq.php',
        ],
        [
            'title'    => 'Get Involved',
            'slug'     => 'get-involved',
            'template' => 'page-get-involved.php',
        ],
        [
            'title'    => 'Volunteer',
            'slug'     => 'volunteer',
            'template' => 'page-volunteer.php',
        ],
        [
            'title'    => 'Contact',
            'slug'     => 'contact',
            'template' => 'page-contact.php',
        ],
        [
            'title'    => 'Donate',
            'slug'     => 'donate',
            'template' => 'page-donate.php',
        ],
        [
            'title'    => 'Blog',
            'slug'     => 'blog',
            'template' => 'home.php',
        ],
    ];

    $home_page_id = 0;
    $blog_page_id = 0;

    foreach ($pages as $p) {
        $existing = get_page_by_path($p['slug']);
        if (!$existing) {
            $page_id = wp_insert_post([
                'post_title'    => $p['title'],
                'post_content'  => '',
                'post_status'   => 'publish',
                'post_type'     => 'page',
                'post_name'     => $p['slug'],
                'post_author'   => 1,
            ]);
            if ($page_id && !is_wp_error($page_id)) {
                update_post_meta($page_id, '_wp_page_template', $p['template']);
                if ($p['slug'] === 'home') $home_page_id = $page_id;
                if ($p['slug'] === 'blog') $blog_page_id = $page_id;
            }
        } else {
            update_post_meta($existing->ID, '_wp_page_template', $p['template']);
            if ($p['slug'] === 'home') $home_page_id = $existing->ID;
            if ($p['slug'] === 'blog') $blog_page_id = $existing->ID;
        }
    }

    // Configure static front page and blog page
    if ($home_page_id) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $home_page_id);
    }
    if ($blog_page_id) {
        update_option('page_for_posts', $blog_page_id);
    }
}
add_action('init', 'one_more_tree_provision_default_pages');
