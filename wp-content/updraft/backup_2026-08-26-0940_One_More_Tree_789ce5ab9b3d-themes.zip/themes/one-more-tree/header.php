<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @package One_More_Tree
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <link rel="icon" href="<?php echo get_template_directory_uri(); ?>/assets/images/favicon.ico">
    <link rel="apple-touch-icon" href="<?php echo get_template_directory_uri(); ?>/assets/images/apple-touch-icon.png">
    <?php wp_head(); ?>
</head>

<body <?php body_class('min-h-screen bg-background text-foreground antialiased'); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site relative min-h-screen bg-background">
    <div class="noise-overlay" aria-hidden="true"></div>

    <a class="skip-link screen-reader-text sr-only" href="#primary">
        <?php _e('Skip to content', 'one-more-tree'); ?>
    </a>

    <!-- Disclaimer Ribbon - Exact mirror of Next.js PublicChrome / DisclaimerRibbon -->
    <?php
    $omt_disclaimer = get_option('omt_admin_disclaimer');
    $disclaimer_show = isset($omt_disclaimer['show']) ? (bool)$omt_disclaimer['show'] : true;
    $disclaimer_msg  = !empty($omt_disclaimer['message'])
        ? $omt_disclaimer['message']
        : '🌳 OneMoreTree NGO is a volunteer-led initiative. All donations go directly to tree planting, site restoration, and community programs.';
    if ($disclaimer_show):
    ?>
    <div
      id="disclaimer-ribbon"
      role="status"
      aria-label="Site disclaimer"
      class="fixed top-0 left-0 right-0 z-[60] w-full bg-forest-900 text-forest-50 transition-all duration-300"
    >

      <div class="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
        <div class="flex items-center justify-between gap-3 py-1.5 text-[11px] sm:text-xs">
          <div class="flex items-center gap-2 min-w-0 flex-1">
            <svg class="w-3.5 h-3.5 flex-shrink-0 opacity-90 text-forest-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <p class="leading-snug break-words line-clamp-2 sm:line-clamp-1">
              <?php echo esc_html($disclaimer_msg); ?>
            </p>
          </div>

          <button
            id="dismiss-disclaimer-btn"
            type="button"
            aria-label="Dismiss disclaimer"
            class="flex-shrink-0 inline-flex items-center justify-center w-6 h-6 rounded-full hover:bg-forest-700/60 transition-colors"
          >
            <svg class="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
          </button>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <!-- Navigation - Exact mirror of Next.js Navigation.tsx -->
    <nav
      id="site-navigation"
      style="top: var(--disclaimer-h, 0px)"
      class="site-navigation fixed left-0 right-0 z-50 transition-all duration-500 bg-white md:bg-transparent md:bg-gradient-to-b md:from-white/90 md:to-transparent"
    >
      <div class="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
        <div class="flex items-center justify-between h-16 sm:h-20">
          <a href="<?php echo esc_url(home_url('/')); ?>" class="flex items-center gap-2 group">
            <img
              src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.png"
              alt="OneMoreTree"
              class="h-8 w-auto sm:h-10 transition-transform duration-300 group-hover:scale-105"
            />
            <span class="font-serif text-lg sm:text-xl font-bold text-foreground">
              OneMore<span class="text-forest-600">Tree</span>
            </span>
          </a>

          <div class="hidden md:flex items-center gap-8">
            <a
              href="<?php echo esc_url(home_url('/')); ?>"
              class="nav-link text-sm transition-colors duration-300 font-medium text-foreground/70 hover:text-forest-600"
              data-path="/"
            >
              Home
            </a>
            <a
              href="<?php echo esc_url(home_url('/about')); ?>"
              class="nav-link text-sm transition-colors duration-300 font-medium text-foreground/70 hover:text-forest-600"
              data-path="/about"
            >
              About
            </a>
            <a
              href="<?php echo esc_url(home_url('/projects')); ?>"
              class="nav-link text-sm transition-colors duration-300 font-medium text-foreground/70 hover:text-forest-600"
              data-path="/projects"
            >
              Projects
            </a>
            <a
              href="<?php echo esc_url(home_url('/impact')); ?>"
              class="nav-link text-sm transition-colors duration-300 font-medium text-foreground/70 hover:text-forest-600"
              data-path="/impact"
            >
              Impact
            </a>
            <a
              href="<?php echo esc_url(home_url('/faq')); ?>"
              class="nav-link text-sm transition-colors duration-300 font-medium text-foreground/70 hover:text-forest-600"
              data-path="/faq"
            >
              FAQ
            </a>
            <a
              href="<?php echo esc_url(home_url('/get-involved')); ?>"
              class="nav-link text-sm transition-colors duration-300 font-medium text-foreground/70 hover:text-forest-600"
              data-path="/get-involved"
            >
              Get Involved
            </a>
            <a
              href="<?php echo esc_url(home_url('/get-involved')); ?>"
              class="px-5 py-2.5 bg-forest-600 hover:bg-forest-700 text-white text-sm font-semibold rounded-full transition-all duration-300 shadow-medium hover:shadow-elevated"
            >
              Donate Now
            </a>
          </div>

          <button
            id="mobile-menu-btn"
            class="md:hidden p-2 text-foreground/70 hover:text-forest-600 transition-colors"
            aria-label="Toggle menu"
          >
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
            </svg>
          </button>
        </div>

        <div id="mobile-menu" class="md:hidden absolute top-full left-0 right-0 bg-white border-b border-earth-200 shadow-medium hidden">
          <div class="px-4 py-6 space-y-4">
            <a
              href="<?php echo esc_url(home_url('/')); ?>"
              class="block w-full text-left text-lg transition-colors duration-300 py-2 font-medium text-foreground/70 hover:text-forest-600"
            >
              Home
            </a>
            <a
              href="<?php echo esc_url(home_url('/about')); ?>"
              class="block w-full text-left text-lg transition-colors duration-300 py-2 font-medium text-foreground/70 hover:text-forest-600"
            >
              About
            </a>
            <a
              href="<?php echo esc_url(home_url('/projects')); ?>"
              class="block w-full text-left text-lg transition-colors duration-300 py-2 font-medium text-foreground/70 hover:text-forest-600"
            >
              Projects
            </a>
            <a
              href="<?php echo esc_url(home_url('/impact')); ?>"
              class="block w-full text-left text-lg transition-colors duration-300 py-2 font-medium text-foreground/70 hover:text-forest-600"
            >
              Impact
            </a>
            <a
              href="<?php echo esc_url(home_url('/faq')); ?>"
              class="block w-full text-left text-lg transition-colors duration-300 py-2 font-medium text-foreground/70 hover:text-forest-600"
            >
              FAQ
            </a>
            <a
              href="<?php echo esc_url(home_url('/get-involved')); ?>"
              class="block w-full text-left text-lg transition-colors duration-300 py-2 font-medium text-foreground/70 hover:text-forest-600"
            >
              Get Involved
            </a>
            <a
              href="<?php echo esc_url(home_url('/donate')); ?>"
              class="block w-full mt-4 px-5 py-3 bg-forest-600 hover:bg-forest-700 text-white font-semibold rounded-full transition-all duration-300 shadow-medium text-center"
            >
              Donate Now
            </a>
          </div>
        </div>
      </div>
    </nav>

    <div id="content" class="site-content">
